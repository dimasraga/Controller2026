#ifndef SYSTEM_MONITOR_HPP
#define SYSTEM_MONITOR_HPP

#include <Arduino.h>
#include "esp_system.h"
#include "esp_heap_caps.h"

class SystemMonitor
{
public:
    SystemMonitor() {}

    // Fungsi cetak status ringkas (Hemat CPU & Memori)
    void printCurrent()
    {
        uint32_t freeHeap = ESP.getFreeHeap();
        uint32_t totalHeap = ESP.getHeapSize();
        uint32_t minFreeHeap = ESP.getMinFreeHeap();
        
        // Hitung persentase pakai integer math biar cepat (x100 dulu baru bagi)
        uint8_t heapPct = (totalHeap > 0) ? ((totalHeap - freeHeap) * 100) / totalHeap : 0;

        Serial.println(F("\n--- [ SYS MONITOR ] ---"));
        
        // Menggunakan printf jauh lebih hemat daripada String() + String()
        Serial.printf("HEAP : %u / %u bytes (%u%% used)\n", freeHeap, totalHeap, heapPct);
        Serial.printf("MIN  : %u bytes (Lowest)\n", minFreeHeap);
        
        // PSRAM (Jika ada)
        if (ESP.getPsramSize() > 0) {
            Serial.printf("PSRAM: %u / %u bytes\n", ESP.getFreePsram(), ESP.getPsramSize());
        }

        // Info Task & Waktu
        Serial.printf("TASK : %u active\n", uxTaskGetNumberOfTasks());
        Serial.printf("UP   : %lu sec\n", millis() / 1000);
        Serial.println(F("-----------------------"));
    }

    // Fungsi cek warning ringan (langsung return true/false tanpa print aneh-aneh)
    void checkAndPrintWarnings()
    {
        // Warning jika Heap < 10KB
        if (ESP.getFreeHeap() < 10240) {
            Serial.printf("⚠️ LOW MEMORY: %u bytes left!\n", ESP.getFreeHeap());
        }
        
        // Warning jika Stack task saat ini < 500 bytes
        UBaseType_t stackLeft = uxTaskGetStackHighWaterMark(NULL);
        if (stackLeft < 500) {
            Serial.printf("⚠️ LOW STACK: %u bytes left!\n", stackLeft);
        }
    }

    void begin() {
        // Kosong, tidak butuh inisialisasi berat
    }
};

#endif