#ifndef MBEDTLS_HANDLER_HPP
#define MBEDTLS_HANDLER_HPP

#include <Arduino.h>
#include <Ethernet.h>
#include <ArduinoJson.h>
#include "certs.h"

#include "mbedtls/platform.h"
#include "mbedtls/net_sockets.h"
#include "mbedtls/ssl.h"
#include "mbedtls/entropy.h"
#include "mbedtls/ctr_drbg.h"
#include "mbedtls/error.h"
#include "mbedtls/base64.h"

// Callback Kirim - Optimized
int eth_ssl_send(void *ctx, const unsigned char *buf, size_t len)
{
    EthernetClient *client = (EthernetClient *)ctx;
    if (!client || !client->connected())
        return MBEDTLS_ERR_NET_CONN_RESET;
    
    size_t written = client->write(buf, len);
    if (written > 0) {
        client->flush(); // Ensure data is sent immediately
        return written;
    }
    return MBEDTLS_ERR_SSL_WANT_WRITE;
}

// Callback Terima - Optimized with timeout
int eth_ssl_recv(void *ctx, unsigned char *buf, size_t len)
{
    EthernetClient *client = (EthernetClient *)ctx;
    if (!client || !client->connected())
        return MBEDTLS_ERR_NET_CONN_RESET;
    
    // Wait for data with short timeout
    unsigned long start = millis();
    while (!client->available() && millis() - start < 100) {
        delay(1);
    }
    
    int avail = client->available();
    if (avail > 0) {
        int readLen = (avail > (int)len) ? len : avail;
        return client->read(buf, readLen);
    }
    return MBEDTLS_ERR_SSL_WANT_READ;
}

// Fungsi Utama Request - OPTIMIZED
int perform_https_request_mbedtls(EthernetClient &ethClient, const char *host, const char *path, const char *data, const char *username, const char *password)
{
    int ret;
    mbedtls_entropy_context entropy;
    mbedtls_ctr_drbg_context ctr_drbg;
    mbedtls_ssl_context ssl;
    mbedtls_ssl_config conf;
    mbedtls_x509_crt cacert;

    // 1. Init
    mbedtls_ssl_init(&ssl);
    mbedtls_ssl_config_init(&conf);
    mbedtls_x509_crt_init(&cacert);
    mbedtls_ctr_drbg_init(&ctr_drbg);
    mbedtls_entropy_init(&entropy);

    Serial.printf("\n[HTTPS] Connecting to: %s\n", host);

    // 2. Seed RNG
    const char *pers = "eth_ssl_client";
    if ((ret = mbedtls_ctr_drbg_seed(&ctr_drbg, mbedtls_entropy_func, &entropy, 
                                      (const unsigned char *)pers, strlen(pers))) != 0)
    {
        Serial.printf("[TLS] RNG Seed Failed: -0x%x\n", -ret);
        goto exit;
    }

    // 3. SSL Config - Optimized settings
    mbedtls_ssl_config_defaults(&conf, MBEDTLS_SSL_IS_CLIENT, 
                                MBEDTLS_SSL_TRANSPORT_STREAM, 
                                MBEDTLS_SSL_PRESET_DEFAULT);
    
    mbedtls_ssl_conf_authmode(&conf, MBEDTLS_SSL_VERIFY_NONE); // Skip verification for faster connection
    mbedtls_ssl_conf_rng(&conf, mbedtls_ctr_drbg_random, &ctr_drbg);
    
    // Set timeouts for better stability
    mbedtls_ssl_conf_read_timeout(&conf, 5000); // 5 second read timeout

    if ((ret = mbedtls_ssl_setup(&ssl, &conf)) != 0) {
        Serial.printf("[TLS] Setup Failed: -0x%x\n", -ret);
        goto exit;
    }
    
    if ((ret = mbedtls_ssl_set_hostname(&ssl, host)) != 0) {
        Serial.printf("[TLS] Set Hostname Failed: -0x%x\n", -ret);
        goto exit;
    }

    // 4. TCP Connect with retry
    Serial.print("[TCP] Connecting... ");
    {
        int retries = 3;
        bool connected = false;
        while (retries-- > 0 && !connected) {
            if (ethClient.connect(host, 443)) {
                connected = true;
                Serial.println("OK");
            } else {
                Serial.print(".");
                delay(1000);
            }
        }
        if (!connected) {
            Serial.println(" FAILED");
            ret = -1;
            goto exit;
        }
    }

    // 5. TLS Handshake with timeout
    Serial.print("[TLS] Handshaking... ");
    mbedtls_ssl_set_bio(&ssl, &ethClient, eth_ssl_send, eth_ssl_recv, NULL);
    
    {
        unsigned long handshake_start = millis();
        while ((ret = mbedtls_ssl_handshake(&ssl)) != 0) {
            if (ret != MBEDTLS_ERR_SSL_WANT_READ && ret != MBEDTLS_ERR_SSL_WANT_WRITE) {
                Serial.printf("FAILED (-0x%x)\n", -ret);
                goto exit;
            }
            
            // Timeout after 10 seconds
            if (millis() - handshake_start > 10000) {
                Serial.println("TIMEOUT");
                ret = -1;
                goto exit;
            }
            delay(10);
        }
        Serial.println("OK");
    }

    // 6. Build and Send Request
    {
        // Create Basic Auth
        String auth = String(username) + ":" + String(password);
        unsigned char base64Auth[128] = {0};
        size_t dlen;

        mbedtls_base64_encode(base64Auth, sizeof(base64Auth), &dlen, 
                             (const unsigned char *)auth.c_str(), auth.length());
        base64Auth[dlen] = 0;

        // Build HTTP Request
        String request = String("POST ") + path + " HTTP/1.1\r\n" +
                         "Host: " + host + "\r\n" +
                         "Authorization: Basic " + String((char *)base64Auth) + "\r\n" +
                         "Content-Type: application/json\r\n" +
                         "Content-Length: " + String(strlen(data)) + "\r\n" +
                         "Connection: close\r\n" +
                         "User-Agent: Arduino-MbedTLS\r\n" +
                         "\r\n" +
                         data;

        // Send Request
        Serial.print("[HTTPS] Sending request... ");
        const char *reqBuf = request.c_str();
        size_t reqLen = request.length();
        size_t written = 0;

        while (written < reqLen) {
            ret = mbedtls_ssl_write(&ssl, (const unsigned char *)(reqBuf + written), reqLen - written);
            if (ret > 0) {
                written += ret;
            } else if (ret != MBEDTLS_ERR_SSL_WANT_READ && ret != MBEDTLS_ERR_SSL_WANT_WRITE) {
                Serial.printf("FAILED (-0x%x)\n", -ret);
                goto exit;
            }
            delay(10);
        }
        Serial.printf("OK (%d bytes)\n", written);
    }

    // 7. Read Response - IMPROVED PARSING
    {
        unsigned char buf[512];
        String response = "";
        unsigned long timeout = millis();
        bool headerPassed = false;
        int httpCode = 0;

        Serial.print("[HTTPS] Reading response... ");

        // Read all data
        while (millis() - timeout < 8000) {
            ret = mbedtls_ssl_read(&ssl, buf, sizeof(buf) - 1);
            
            if (ret > 0) {
                buf[ret] = 0;
                response += String((char*)buf);
                timeout = millis(); // Reset timeout on successful read
            } 
            else if (ret == MBEDTLS_ERR_SSL_WANT_READ || ret == MBEDTLS_ERR_SSL_WANT_WRITE) {
                delay(10);
                continue;
            }
            else if (ret == MBEDTLS_ERR_SSL_PEER_CLOSE_NOTIFY || ret == 0) {
                break;
            }
            else {
                Serial.printf("Read error: -0x%x\n", -ret);
                break;
            }
        }
        Serial.println("OK");

        // Parse HTTP Status
        int statusIdx = response.indexOf("HTTP/1.1 ");
        if (statusIdx >= 0) {
            httpCode = response.substring(statusIdx + 9, statusIdx + 12).toInt();
            Serial.printf("[HTTP] Status: %d\n", httpCode);
        }

        // Extract JSON body
        int bodyStart = response.indexOf("\r\n\r\n");
        if (bodyStart >= 0) {
            String body = response.substring(bodyStart + 4);
            
            // Remove chunked encoding artifacts
            int jsonStart = body.indexOf('{');
            int jsonEnd = body.lastIndexOf('}');
            
            if (jsonStart >= 0 && jsonEnd > jsonStart) {
                String jsonStr = body.substring(jsonStart, jsonEnd + 1);
                
                // Parse JSON
                StaticJsonDocument<512> doc;
                DeserializationError error = deserializeJson(doc, jsonStr);
                
                if (!error) {
                    bool isSuccess = doc["isSuccess"] | false;
                    const char* message = doc["message"] | "No message";
                    
                    Serial.println("[Response]");
                    Serial.printf("  Success : %s\n", isSuccess ? "YES" : "NO");
                    Serial.printf("  Message : %s\n", message);
                    
                    ret = isSuccess ? 0 : -1;
                } else {
                    Serial.printf("[JSON] Parse error: %s\n", error.c_str());
                    Serial.println("[JSON] Raw: " + jsonStr);
                    ret = (httpCode == 200) ? 0 : -1;
                }
            } else {
                Serial.println("[Response] No JSON found in body");
                ret = (httpCode == 200) ? 0 : -1;
            }
        } else {
            Serial.println("[Response] No body separator found");
            ret = -1;
        }
    }

exit:
    // Cleanup
    mbedtls_ssl_close_notify(&ssl);
    ethClient.stop();
    mbedtls_ssl_free(&ssl);
    mbedtls_ssl_config_free(&conf);
    mbedtls_x509_crt_free(&cacert);
    mbedtls_ctr_drbg_free(&ctr_drbg);
    mbedtls_entropy_free(&entropy);
    
    Serial.println("[HTTPS] Connection closed\n");
    return (ret == 0) ? 200 : -1;
}

#endif