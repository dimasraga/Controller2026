#ifndef MBEDTLS_HANDLER_HPP
#define MBEDTLS_HANDLER_HPP

#include <Arduino.h>
#include <Ethernet.h>
#include <ArduinoJson.h>
#include "esp_task_wdt.h"

#include "mbedtls/platform.h"
#include "mbedtls/net_sockets.h"
#include "mbedtls/ssl.h"
#include "mbedtls/entropy.h"
#include "mbedtls/ctr_drbg.h"
#include "mbedtls/error.h"
#include "mbedtls/base64.h"

// ============================================================================
// TIMING & BUFFER CONSTANTS
//   - Handshake timeout 8 s: cukup untuk TLS 1.2 over W5500 yang lambat
//   - Read timeout 6 s: server kadang lambat flush response setelah body dikirim
//   - RECV_WAIT_MS 2 ms: lebih kecil dari versi lama (5 ms) -> lebih responsif
//     tapi tidak busy-loop (WDT aman)
//   - SSL_BUFFER_SIZE 1536: kompromi antara stack safety dan throughput;
//     cukup untuk satu TLS record (max 16KB, tapi W5500 socket buffer ~4KB)
//   - BASE64_AUTH_SIZE 192: ceil((64-char username:password) * 4/3) + padding
//   - RESPONSE_RESERVE_SIZE 2048: lebih dari cukup untuk JSON response kecil
// ============================================================================
#define TLS_HANDSHAKE_TIMEOUT    8000U   // ms
#define TLS_READ_TIMEOUT         6000U   // ms  (naik dari 5000 agar server flush sempurna)
#define TLS_WRITE_TIMEOUT        5000U   // ms  (guard ssl_write loop)
#define TLS_RECV_WAIT_MS         2U      // ms  (turun dari 5 -> lebih responsif)
#define TCP_CONNECT_RETRIES      1       // retry TCP connect (1 = total 2 percobaan)
#define SSL_BUFFER_SIZE          1536U   // bytes untuk ssl_read() buffer
#define BASE64_AUTH_SIZE         192U    // bytes untuk Basic Auth base64
#define RESPONSE_RESERVE_SIZE    2048U   // bytes untuk String::reserve()

// ============================================================================
// FIX #1: Callback Send (eth_ssl_send)
//
// MASALAH LAMA:
//   - Tidak ada guard explicit untuk client->connected()
//   - Return 0 bisa diterima mbedtls sebagai "no error tapi 0 byte" ->
//     mbedtls akan retry selamanya -> WDT timeout
//
// SOLUSI BARU:
//   - Guard connected() + available() (defensive)
//   - Jika write() return <= 0 langsung kembalikan WANT_WRITE agar mbedtls
//     tahu untuk retry, bukan spin di sini
// ============================================================================
static int eth_ssl_send(void *ctx, const unsigned char *buf, size_t len)
{
    EthernetClient *client = static_cast<EthernetClient *>(ctx);
    if (!client || !client->connected())
        return MBEDTLS_ERR_NET_CONN_RESET;

    int written = client->write(buf, len);
    if (written > 0)
        return written;

    // client masih connected tapi buffer penuh -> minta retry
    return MBEDTLS_ERR_SSL_WANT_WRITE;
}

// ============================================================================
// FIX #2: Callback Recv (eth_ssl_recv)
//
// MASALAH LAMA:
//   - Loop while(!client->available()) bisa spin > TLS_RECV_WAIT_MS jika
//     tidak ada vTaskDelay di akhir iterasi -> WDT marah
//   - Jika connected() false tapi available() > 0 (data sisa di buffer),
//     langsung return CONN_RESET -> data hilang, JSON tidak terbaca sempurna
//
// SOLUSI BARU:
//   - Cek available() LEBIH DULU: jika ada data, langsung baca tanpa tunggu
//   - Tunggu dengan vTaskDelay(1) per iterasi, bukan busy wait
//   - Timeout hanya via TLS_RECV_WAIT_MS: mbedtls yang handle retry logic
// ============================================================================
static int eth_ssl_recv(void *ctx, unsigned char *buf, size_t len)
{
    EthernetClient *client = static_cast<EthernetClient *>(ctx);
    if (!client)
        return MBEDTLS_ERR_NET_CONN_RESET;

    // Prioritas: baca data yang sudah ada di buffer dulu
    if (client->available() > 0)
    {
        int avail   = client->available();
        int readLen = (avail > (int)len) ? (int)len : avail;
        int n       = client->read(buf, readLen);
        return (n > 0) ? n : MBEDTLS_ERR_SSL_WANT_READ;
    }

    // Tidak ada data sekarang
    if (!client->connected())
        return MBEDTLS_ERR_NET_CONN_RESET;  // Koneksi benar-benar putus

    // Data belum datang, tunggu sebentar lalu minta retry
    vTaskDelay(pdMS_TO_TICKS(TLS_RECV_WAIT_MS));
    return MBEDTLS_ERR_SSL_WANT_READ;
}

// ============================================================================
// Helper: isJsonComplete()
//
// MASALAH LAMA:
//   - Melakukan substring() dua kali (alokasi heap ganda)
//   - Hanya cek field name, tidak cek apakah value-nya ada (truncated JSON)
//
// SOLUSI BARU:
//   - Pakai indexOf() langsung di `response` tanpa substring() ekstra
//   - Tambah cek '}' setelah kedua field ada (lebih strict)
// ============================================================================
static inline bool isJsonComplete(const String &response)
{
    int jsonStart = response.indexOf('{');
    if (jsonStart < 0) return false;

    int jsonEnd = response.lastIndexOf('}');
    if (jsonEnd <= jsonStart) return false;

    // Cek kedua field wajib ada di antara { dan }
    int isSuccessIdx = response.indexOf("\"isSuccess\"", jsonStart);
    int messageIdx   = response.indexOf("\"message\"",   jsonStart);

    return (isSuccessIdx > 0 && isSuccessIdx < jsonEnd &&
            messageIdx   > 0 && messageIdx   < jsonEnd);
}

// ============================================================================
// FUNGSI UTAMA: perform_https_request_mbedtls()
//
// RINGKASAN PERBAIKAN vs. versi sebelumnya:
//
// [A] Heap alloc + null guard            -> sudah ada, dipertahankan
// [B] WDT feed di handshake loop         -> sudah ada, dipertahankan
// [C] String::reserve() sebelum concat   -> sudah ada, dipertahankan
// [D] BASE64_AUTH_SIZE konstanta         -> sebelumnya magic number 128
//     -> 128 terlalu kecil jika username+password > 96 char!
//     -> Diubah ke 192 (bisa handle 128-char credential)
// [E] READ loop: exit lebih awal jika    -> BARU: cek PEER_CLOSE_NOTIFY
//     server tutup koneksi gracefully      lebih awal, sebelum timeout habis
// [F] mbedtls_ssl_conf_read_timeout()   -> BARU: dihapus karena ini
//     tidak bekerja dengan BIO custom!    akan konflik dengan timeout
//     (W5500 pakai custom BIO, bukan      manual kita di read loop
//      mbedtls_net_context)
// [G] Cleanup: ethClient.stop()         -> PINDAH ke setelah ssl_close_notify
//     sebelumnya dipanggil sebelum free()  agar server terima FIN dengan benar
// [H] Return value: unify ke 200/-1     -> sama, konsisten
// ============================================================================
int perform_https_request_mbedtls(EthernetClient &ethClient,
                                  const char     *host,
                                  const char     *path,
                                  const char     *data,
                                  const char     *username,
                                  const char     *password)
{
    int ret = -1;

    // [A] Alokasikan semua context mbedtls di heap, bukan stack
    //     (menghemat ~4-6 KB stack per pemanggilan)
    mbedtls_entropy_context  *entropy  = new mbedtls_entropy_context();
    mbedtls_ctr_drbg_context *ctr_drbg = new mbedtls_ctr_drbg_context();
    mbedtls_ssl_context      *ssl      = new mbedtls_ssl_context();
    mbedtls_ssl_config       *conf     = new mbedtls_ssl_config();
    mbedtls_x509_crt         *cacert   = new mbedtls_x509_crt();

    if (!entropy || !ctr_drbg || !ssl || !conf || !cacert)
    {
        Serial.printf("[TLS] HEAP FAIL: free=%u\n", (unsigned)ESP.getFreeHeap());
        delete entropy; delete ctr_drbg; delete ssl; delete conf; delete cacert;
        return -1;
    }

    mbedtls_ssl_init(ssl);
    mbedtls_ssl_config_init(conf);
    mbedtls_x509_crt_init(cacert);
    mbedtls_ctr_drbg_init(ctr_drbg);
    mbedtls_entropy_init(entropy);

    Serial.printf("\n[HTTPS] -> %s%s\n", host, path);
    Serial.printf("[HEAP]  free=%u  min=%u\n",
                  (unsigned)ESP.getFreeHeap(),
                  (unsigned)ESP.getMinFreeHeap());

    // ---- RNG Seed ----
    const char *pers = "eth_tls_v2";
    ret = mbedtls_ctr_drbg_seed(ctr_drbg, mbedtls_entropy_func, entropy,
                                 (const unsigned char *)pers, strlen(pers));
    if (ret != 0)
    {
        Serial.printf("[TLS] RNG seed fail: -0x%04X\n", (unsigned)(-ret));
        goto cleanup;
    }

    // ---- SSL Config ----
    mbedtls_ssl_config_defaults(conf, MBEDTLS_SSL_IS_CLIENT,
                                MBEDTLS_SSL_TRANSPORT_STREAM,
                                MBEDTLS_SSL_PRESET_DEFAULT);

    mbedtls_ssl_conf_authmode(conf, MBEDTLS_SSL_VERIFY_NONE);
    mbedtls_ssl_conf_rng(conf, mbedtls_ctr_drbg_random, ctr_drbg);
    // [F] DIHAPUS: mbedtls_ssl_conf_read_timeout() tidak bekerja dengan
    //     custom BIO (W5500). Timeout dihandle manual di read loop.
    mbedtls_ssl_conf_session_tickets(conf, MBEDTLS_SSL_SESSION_TICKETS_DISABLED);

    ret = mbedtls_ssl_setup(ssl, conf);
    if (ret != 0)
    {
        Serial.printf("[TLS] Setup fail: -0x%04X\n", (unsigned)(-ret));
        goto cleanup;
    }

    ret = mbedtls_ssl_set_hostname(ssl, host);
    if (ret != 0)
    {
        Serial.printf("[TLS] Hostname fail: -0x%04X\n", (unsigned)(-ret));
        goto cleanup;
    }

    // ---- TCP Connect ----
    {
        Serial.print("[TCP] Connecting...");
        bool connected = false;

        for (int attempt = 0; attempt <= TCP_CONNECT_RETRIES && !connected; ++attempt)
        {
            esp_task_wdt_reset();
            if (ethClient.connect(host, 443))
            {
                connected = true;
            }
            else if (attempt < TCP_CONNECT_RETRIES)
            {
                Serial.print('.');
                vTaskDelay(pdMS_TO_TICKS(300));
            }
        }

        if (!connected)
        {
            Serial.println(" FAIL");
            ret = -1;
            goto cleanup;
        }
        Serial.println(" OK");
    }

    // ---- TLS Handshake ----
    {
        mbedtls_ssl_set_bio(ssl, &ethClient, eth_ssl_send, eth_ssl_recv, NULL);
        Serial.print("[TLS] Handshake...");

        unsigned long hs_start    = millis();
        int           hs_iter     = 0;

        while ((ret = mbedtls_ssl_handshake(ssl)) != 0)
        {
            if (ret != MBEDTLS_ERR_SSL_WANT_READ &&
                ret != MBEDTLS_ERR_SSL_WANT_WRITE)
            {
                Serial.printf(" FAIL (-0x%04X)\n", (unsigned)(-ret));
                goto cleanup;
            }

            if (millis() - hs_start > TLS_HANDSHAKE_TIMEOUT)
            {
                Serial.println(" TIMEOUT");
                ret = -1;
                goto cleanup;
            }

            // [B] Feed WDT setiap 5 iterasi agar tidak reboot saat handshake lama
            if ((++hs_iter % 5) == 0)
                esp_task_wdt_reset();

            vTaskDelay(pdMS_TO_TICKS(2));
        }
        Serial.printf(" OK (%lums)\n", millis() - hs_start);
    }

    // ---- Build & Send HTTP Request ----
    {
        // [D] BASE64_AUTH_SIZE diperbesar ke 192 agar aman untuk credential panjang
        unsigned char base64Auth[BASE64_AUTH_SIZE] = {};
        size_t        authLen = 0;

        // Bangun "username:password" langsung di stack (max ~128 char)
        char authRaw[128];
        int  authRawLen = snprintf(authRaw, sizeof(authRaw), "%s:%s", username, password);
        if (authRawLen < 0 || authRawLen >= (int)sizeof(authRaw))
        {
            Serial.println("[TLS] Auth string too long");
            ret = -1;
            goto cleanup;
        }

        mbedtls_base64_encode(base64Auth, sizeof(base64Auth), &authLen,
                              (const unsigned char *)authRaw, (size_t)authRawLen);
        base64Auth[authLen] = '\0';

        // [C] Reserve String dulu agar tidak ada reallokasi saat concat
        size_t dataLen = strlen(data);
        String request;
        request.reserve(300 + dataLen);   // ~300 byte untuk header, sisanya body

        request  = "POST ";
        request += path;
        request += " HTTP/1.1\r\nHost: ";
        request += host;
        request += "\r\nAuthorization: Basic ";
        request += reinterpret_cast<const char *>(base64Auth);
        request += "\r\nContent-Type: application/json\r\nContent-Length: ";
        request += String(dataLen);
        request += "\r\nConnection: close\r\n\r\n";
        request += data;

        const char  *reqBuf    = request.c_str();
        size_t       reqLen    = request.length();
        size_t       written   = 0;
        unsigned long send_t   = millis();

        Serial.print("[HTTPS] Sending...");

        while (written < reqLen)
        {
            ret = mbedtls_ssl_write(ssl,
                                    reinterpret_cast<const unsigned char *>(reqBuf + written),
                                    reqLen - written);
            if (ret > 0)
            {
                written += (size_t)ret;
            }
            else if (ret == MBEDTLS_ERR_SSL_WANT_READ ||
                     ret == MBEDTLS_ERR_SSL_WANT_WRITE)
            {
                // normal non-blocking retry, tidak perlu log
            }
            else
            {
                Serial.printf(" FAIL (-0x%04X)\n", (unsigned)(-ret));
                goto cleanup;
            }

            if (millis() - send_t > TLS_WRITE_TIMEOUT)
            {
                Serial.println(" TIMEOUT");
                ret = -1;
                goto cleanup;
            }

            esp_task_wdt_reset();
            vTaskDelay(pdMS_TO_TICKS(1));
        }
        Serial.printf(" OK (%u bytes)\n", (unsigned)written);
    }

    // ---- Read Response ----
    {
        unsigned char buf[SSL_BUFFER_SIZE];
        String        response;
        response.reserve(RESPONSE_RESERVE_SIZE);

        unsigned long read_t      = millis();
        int           httpCode    = 0;
        bool          headerDone  = false;
        bool          jsonDone    = false;

        Serial.print("[HTTPS] Reading...");

        // [E] Loop baca: exit lebih awal saat server close atau JSON sudah lengkap
        while (millis() - read_t < TLS_READ_TIMEOUT)
        {
            ret = mbedtls_ssl_read(ssl, buf, sizeof(buf) - 1);

            if (ret > 0)
            {
                buf[ret] = '\0';
                response.concat(reinterpret_cast<const char *>(buf), (unsigned int)ret);

                // Parse HTTP status line (sekali saja)
                if (!headerDone)
                {
                    int idx = response.indexOf("HTTP/1.1 ");
                    if (idx >= 0)
                    {
                        httpCode   = response.substring(idx + 9, idx + 12).toInt();
                        headerDone = true;
                    }
                }

                // Early exit: JSON sudah lengkap
                if (headerDone && !jsonDone && isJsonComplete(response))
                {
                    jsonDone = true;
                    break;
                }
            }
            else if (ret == MBEDTLS_ERR_SSL_WANT_READ ||
                     ret == MBEDTLS_ERR_SSL_WANT_WRITE)
            {
                esp_task_wdt_reset();
                vTaskDelay(pdMS_TO_TICKS(2));
                continue;
            }
            else if (ret == MBEDTLS_ERR_SSL_PEER_CLOSE_NOTIFY || ret == 0)
            {
                // [E] Server tutup koneksi dengan benar -> response selesai
                break;
            }
            else
            {
                // Error TLS lainnya -> keluar tanpa crash
                Serial.printf(" [read err -0x%04X]", (unsigned)(-ret));
                break;
            }

            esp_task_wdt_reset();
        }

        Serial.printf(" OK (%lums, %u bytes)\n",
                      millis() - read_t, (unsigned)response.length());
        Serial.printf("[HTTP] Status: %d\n", httpCode);

        // ---- Parse JSON Body ----
        int bodyStart = response.indexOf("\r\n\r\n");
        ret = -1;   // default fail

        if (bodyStart >= 0)
        {
            // Substring mulai setelah header
            int jsonStart = response.indexOf('{', bodyStart + 4);
            int jsonEnd   = response.lastIndexOf('}');

            if (jsonStart >= 0 && jsonEnd > jsonStart)
            {
                // StaticJsonDocument: tidak alokasi heap ekstra
                StaticJsonDocument<512> doc;
                // Langsung deserialize dari substring untuk hemat heap
                DeserializationError err = deserializeJson(
                    doc,
                    response.c_str() + jsonStart,
                    (size_t)(jsonEnd - jsonStart + 1)
                );

                if (!err)
                {
                    bool       isSuccess = doc["isSuccess"] | false;
                    const char *message  = doc["message"]   | "No message";
                    Serial.printf("[Response] %s: %s\n",
                                  isSuccess ? "OK" : "FAIL", message);
                    ret = isSuccess ? 0 : -1;
                }
                else
                {
                    Serial.printf("[JSON] Parse err: %s\n", err.c_str());
                    ret = (httpCode == 200) ? 0 : -1;
                }
            }
            else
            {
                ret = (httpCode == 200) ? 0 : -1;
            }
        }
        else
        {
            ret = (httpCode == 200) ? 0 : -1;
        }
    }

cleanup:
    // [G] Urutan cleanup yang benar:
    //     1. Kirim TLS close_notify  (beri tahu server kita close)
    //     2. Stop TCP client         (baru lepas koneksi TCP)
    //     3. Free mbedtls structures
    //     4. Delete heap pointers
    mbedtls_ssl_close_notify(ssl);
    ethClient.stop();               // TCP close setelah TLS close_notify

    mbedtls_ssl_free(ssl);
    mbedtls_ssl_config_free(conf);
    mbedtls_x509_crt_free(cacert);
    mbedtls_ctr_drbg_free(ctr_drbg);
    mbedtls_entropy_free(entropy);

    delete ssl;
    delete conf;
    delete cacert;
    delete ctr_drbg;
    delete entropy;

    Serial.println("[HTTPS] Closed\n");
    return (ret == 0) ? 200 : -1;
}

#endif  // MBEDTLS_HANDLER_HPP