#ifndef SYSTEM_MONITOR_HPP
#define SYSTEM_MONITOR_HPP
#include <Arduino.h>
#include "esp_system.h"
#include "esp_task_wdt.h"
#include "esp_chip_info.h"
#include "soc/rtc.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

struct SystemMetrics
{
    uint32_t freeHeap;
    uint32_t totalHeap;
    uint32_t minFreeHeap;
    uint32_t usedHeap;
    float heapUsagePercent;
    uint32_t freePSRAM;
    uint32_t totalPSRAM;
    uint32_t cpuFreqMHz;
    uint32_t apbFreqHz;
    uint8_t numCores;
    uint32_t numTasks;
    uint32_t stackHighWaterMark;
    uint32_t uptimeSeconds;
    uint32_t freeSketchSpace;
    uint32_t sketchSize;
};

class SystemMonitor
{
private:
    SystemMetrics beforeMetrics;
    SystemMetrics afterMetrics;
    unsigned long startTime;
    bool isMonitoring;

    void captureMetrics(SystemMetrics &metrics)
    {
        metrics.freeHeap = ESP.getFreeHeap();
        metrics.totalHeap = ESP.getHeapSize();
        metrics.minFreeHeap = ESP.getMinFreeHeap();
        metrics.usedHeap = metrics.totalHeap - metrics.freeHeap;
        metrics.heapUsagePercent = ((float)metrics.usedHeap / (float)metrics.totalHeap) * 100.0f;
        metrics.freePSRAM = ESP.getFreePsram();
        metrics.totalPSRAM = ESP.getPsramSize();
        esp_chip_info_t chip_info;
        esp_chip_info(&chip_info);
        metrics.cpuFreqMHz = ESP.getCpuFreqMHz();
        metrics.apbFreqHz = rtc_clk_apb_freq_get();
        metrics.numCores = chip_info.cores;
        metrics.numTasks = uxTaskGetNumberOfTasks();
        metrics.stackHighWaterMark = uxTaskGetStackHighWaterMark(NULL);
        metrics.uptimeSeconds = millis() / 1000;
        metrics.freeSketchSpace = ESP.getFreeSketchSpace();
        metrics.sketchSize = ESP.getSketchSize();
    }

    String formatBytes(uint32_t bytes)
    {
        if (bytes < 1024)
        {
            return String(bytes) + " B";
        }
        else if (bytes < 1024 * 1024)
        {
            return String(bytes / 1024.0, 2) + " KB";
        }
        else
        {
            return String(bytes / (1024.0 * 1024.0), 2) + " MB";
        }
    }

public:
    SystemMonitor() : isMonitoring(false) {}

    void begin()
    {
        startTime = millis();
        captureMetrics(beforeMetrics);
        isMonitoring = true;
    }

    void end()
    {
        if (!isMonitoring)
            return;

        captureMetrics(afterMetrics);
        unsigned long duration = millis() - startTime;
        isMonitoring = false;

        Serial.println("SYSTEM MONITORING - END");
        Serial.printf("⏱️  Duration: %lu ms\n\n", duration);

        printComparison();
    }

    void printCurrent()
    {
        SystemMetrics current;
        captureMetrics(current);

        Serial.println("SYSTEM STATUS - CURRENT");

        Serial.println("┌─ CPU INFORMATION ───────────────────────────────────────────┐");
        Serial.printf("│ CPU Frequency    : %u MHz\n", current.cpuFreqMHz);
        Serial.printf("│ APB Frequency    : %.2f MHz\n", current.apbFreqHz / 1000000.0f);
        Serial.printf("│ Number of Cores  : %u\n", current.numCores);
        Serial.printf("│ Chip Model       : ESP32 Rev %u\n", ESP.getChipRevision());

        Serial.println("┌─ MEMORY (RAM) INFORMATION ──────────────────────────────────┐");
        Serial.printf("│ Total Heap       : %s\n", formatBytes(current.totalHeap).c_str());
        Serial.printf("│ Free Heap        : %s\n", formatBytes(current.freeHeap).c_str());
        Serial.printf("│ Used Heap        : %s\n", formatBytes(current.usedHeap).c_str());
        Serial.printf("│ Min Free Heap    : %s (lowest point since boot)\n", formatBytes(current.minFreeHeap).c_str());
        Serial.printf("│ Heap Usage       : %.2f%%\n", current.heapUsagePercent);

        Serial.print("│ Usage Bar        : [");
        int barLength = 40;
        int filledLength = (int)(current.heapUsagePercent / 100.0f * barLength);
        for (int i = 0; i < barLength; i++)
        {
            if (i < filledLength)
                Serial.print("█");
            else
                Serial.print("░");
        }

        if (current.totalPSRAM > 0)
        {
            float psramUsagePercent = ((float)(current.totalPSRAM - current.freePSRAM) / (float)current.totalPSRAM) * 100.0f;
            Serial.println("┌─ PSRAM INFORMATION ─────────────────────────────────────────┐");
            Serial.printf("│ Total PSRAM      : %s\n", formatBytes(current.totalPSRAM).c_str());
            Serial.printf("│ Free PSRAM       : %s\n", formatBytes(current.freePSRAM).c_str());
            Serial.printf("│ Used PSRAM       : %s\n", formatBytes(current.totalPSRAM - current.freePSRAM).c_str());
            Serial.printf("│ PSRAM Usage      : %.2f%%\n", psramUsagePercent);
        }

        Serial.println("┌─ TASK & SYSTEM INFORMATION ─────────────────────────────────┐");
        Serial.printf("│ Active Tasks     : %u\n", current.numTasks);
        Serial.printf("│ Stack Available  : %u bytes (current task)\n", current.stackHighWaterMark);
        Serial.printf("│ System Uptime    : %u seconds (%.2f hours)\n",
                      current.uptimeSeconds, current.uptimeSeconds / 3600.0f);

        Serial.println("┌─ FLASH INFORMATION ─────────────────────────────────────────┐");
        Serial.printf("│ Sketch Size      : %s\n", formatBytes(current.sketchSize).c_str());
        Serial.printf("│ Free Flash Space : %s\n", formatBytes(current.freeSketchSpace).c_str());
        Serial.printf("│ Flash Size       : %s\n", formatBytes(ESP.getFlashChipSize()).c_str());
    }

    void printComparison()
    {
        int32_t heapDelta = (int32_t)afterMetrics.freeHeap - (int32_t)beforeMetrics.freeHeap;
        float heapUsageDelta = afterMetrics.heapUsagePercent - beforeMetrics.heapUsagePercent;
        int32_t tasksDelta = (int32_t)afterMetrics.numTasks - (int32_t)beforeMetrics.numTasks;

        Serial.println("┌─ BEFORE vs AFTER COMPARISON ────────────────────────────────┐");
        Serial.println("│ MEMORY (HEAP):                                               │");
        Serial.printf("│   Before: %s free (%.2f%% used)\n",
                      formatBytes(beforeMetrics.freeHeap).c_str(),
                      beforeMetrics.heapUsagePercent);
        Serial.printf("│   After : %s free (%.2f%% used)\n",
                      formatBytes(afterMetrics.freeHeap).c_str(),
                      afterMetrics.heapUsagePercent);
        Serial.printf("│   Delta : %s%s ",
                      (heapDelta >= 0) ? "+" : "",
                      formatBytes(abs(heapDelta)).c_str());
        if (heapDelta > 0)
        {
            Serial.println("(freed) ✓");
        }
        else if (heapDelta < 0)
        {
            Serial.println("(allocated) ⚠");
        }
        else
        {
            Serial.println("(no change)");
        }
        Serial.printf("│   Usage : %+.2f%%\n", heapUsageDelta);
        Serial.println("│                                                              │");

        Serial.println("│ CPU:                                                         │");
        Serial.printf("│   Frequency: %u MHz ", afterMetrics.cpuFreqMHz);
        if (afterMetrics.cpuFreqMHz != beforeMetrics.cpuFreqMHz)
        {
            Serial.printf("(was %u MHz)", beforeMetrics.cpuFreqMHz);
        }
        Serial.println();
        Serial.printf("│   Cores    : %u\n", afterMetrics.numCores);
        Serial.println("│                                                              │");

        Serial.println("│ TASKS:                                                       │");
        Serial.printf("│   Before: %u active tasks\n", beforeMetrics.numTasks);
        Serial.printf("│   After : %u active tasks\n", afterMetrics.numTasks);
        Serial.printf("│   Delta : %+d tasks\n", tasksDelta);
        Serial.println("│                                                              │");

        Serial.println("│ STACK (Current Task):                                        │");
        Serial.printf("│   Before: %u bytes available\n", beforeMetrics.stackHighWaterMark);
        Serial.printf("│   After : %u bytes available\n", afterMetrics.stackHighWaterMark);
        int32_t stackDelta = (int32_t)afterMetrics.stackHighWaterMark - (int32_t)beforeMetrics.stackHighWaterMark;
        Serial.printf("│   Delta : %+d bytes ", stackDelta);
        if (stackDelta < 0)
        {
            Serial.println("(deeper stack used) ⚠");
        }
        else if (stackDelta > 0)
        {
            Serial.println("(released) ✓");
        }
        else
        {
            Serial.println();
        }
    }

    SystemMetrics getCurrentMetrics()
    {
        SystemMetrics current;
        captureMetrics(current);
        return current;
    }

    void printQuickStats()
    {
        SystemMetrics current;
        captureMetrics(current);

        Serial.printf("[SYS] CPU:%uMHz | RAM:%s/%s (%.1f%%) | Tasks:%u | Uptime:%us\n",
                      current.cpuFreqMHz,
                      formatBytes(current.freeHeap).c_str(),
                      formatBytes(current.totalHeap).c_str(),
                      current.heapUsagePercent,
                      current.numTasks,
                      current.uptimeSeconds);
    }

    bool isMemoryLow(uint32_t thresholdBytes = 10240)
    {
        return (ESP.getFreeHeap() < thresholdBytes);
    }

    void checkAndPrintWarnings()
    {
        SystemMetrics current;
        captureMetrics(current);

        bool hasWarning = false;

        if (current.freeHeap < 10240)
        {
            if (!hasWarning)
            {
                Serial.println("\n⚠️  SYSTEM WARNINGS:");
                hasWarning = true;
            }
            Serial.printf("  • LOW MEMORY: Only %s free heap remaining!\n",
                          formatBytes(current.freeHeap).c_str());
        }

        if (current.stackHighWaterMark < 512)
        {
            if (!hasWarning)
            {
                Serial.println("\n⚠️  SYSTEM WARNINGS:");
                hasWarning = true;
            }
            Serial.printf("  • LOW STACK: Only %u bytes available in current task!\n",
                          current.stackHighWaterMark);
        }

        if (current.heapUsagePercent > 80.0f)
        {
            if (!hasWarning)
            {
                Serial.println("\n⚠️  SYSTEM WARNINGS:");
                hasWarning = true;
            }
            Serial.printf("  • HIGH MEMORY USAGE: %.1f%% heap used!\n",
                          current.heapUsagePercent);
        }

        if (hasWarning)
        {
            Serial.println();
        }
    }
};

#endif