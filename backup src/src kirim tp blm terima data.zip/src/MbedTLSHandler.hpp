#ifndef MBEDTLS_HANDLER_HPP
#define MBEDTLS_HANDLER_HPP

#include <Arduino.h>
#include <Ethernet.h>
#include "certs.h"

#include "mbedtls/platform.h"
#include "mbedtls/net_sockets.h"
#include "mbedtls/ssl.h"
#include "mbedtls/entropy.h"
#include "mbedtls/ctr_drbg.h"
#include "mbedtls/error.h"
#include "mbedtls/base64.h"

// Callback Kirim
int eth_ssl_send(void *ctx, const unsigned char *buf, size_t len)
{
    EthernetClient *client = (EthernetClient *)ctx;
    if (!client || !client->connected())
        return MBEDTLS_ERR_NET_CONN_RESET;
    size_t written = client->write(buf, len);
    return (written > 0) ? written : MBEDTLS_ERR_SSL_WANT_WRITE;
}

// Callback Terima
int eth_ssl_recv(void *ctx, unsigned char *buf, size_t len)
{
    EthernetClient *client = (EthernetClient *)ctx;
    if (!client || !client->connected())
        return MBEDTLS_ERR_NET_CONN_RESET;
    int avail = client->available();
    if (avail > 0)
    {
        int readLen = (avail > len) ? len : avail;
        return client->read(buf, readLen);
    }
    return MBEDTLS_ERR_SSL_WANT_READ;
}

// Fungsi Utama Request
int perform_https_request_mbedtls(EthernetClient &ethClient, const char *host, const char *path, const char *data, const char *username, const char *password)
{
    int ret;
    mbedtls_entropy_context entropy;
    mbedtls_ctr_drbg_context ctr_drbg;
    mbedtls_ssl_context ssl;
    mbedtls_ssl_config conf;
    mbedtls_x509_crt cacert;

    // 1. Init
    mbedtls_ssl_init(&ssl);
    mbedtls_ssl_config_init(&conf);
    mbedtls_x509_crt_init(&cacert);
    mbedtls_ctr_drbg_init(&ctr_drbg);
    mbedtls_entropy_init(&entropy);

    Serial.printf("\n[mbedTLS] Target: %s\n", host);

    // 2. Seed RNG
    if ((ret = mbedtls_ctr_drbg_seed(&ctr_drbg, mbedtls_entropy_func, &entropy, NULL, 0)) != 0)
    {
        Serial.println("✗ RNG Failed");
        goto exit;
    }

    // 3. Config (Verify None untuk trial)
    mbedtls_ssl_config_defaults(&conf, MBEDTLS_SSL_IS_CLIENT, MBEDTLS_SSL_TRANSPORT_STREAM, MBEDTLS_SSL_PRESET_DEFAULT);
    mbedtls_ssl_conf_authmode(&conf, MBEDTLS_SSL_VERIFY_NONE);
    mbedtls_ssl_conf_rng(&conf, mbedtls_ctr_drbg_random, &ctr_drbg);

    if ((ret = mbedtls_ssl_setup(&ssl, &conf)) != 0)
        goto exit;
    if ((ret = mbedtls_ssl_set_hostname(&ssl, host)) != 0)
        goto exit;

    // 4. TCP Connect
    if (!ethClient.connect(host, 443))
    {
        Serial.println("✗ TCP Connect Failed");
        ret = -1;
        goto exit;
    }

    // 5. Handshake
    mbedtls_ssl_set_bio(&ssl, &ethClient, eth_ssl_send, eth_ssl_recv, NULL);
    Serial.print("[TLS] Handshake...");
    while ((ret = mbedtls_ssl_handshake(&ssl)) != 0)
    {
        if (ret != MBEDTLS_ERR_SSL_WANT_READ && ret != MBEDTLS_ERR_SSL_WANT_WRITE)
        {
            Serial.printf(" Failed! (-0x%x)\n", -ret);
            goto exit;
        }
        delay(10);
    }
    Serial.println(" OK");

    // 6. Send Request
    {
        // Basic Auth
        String auth = String(username) + ":" + String(password);
        unsigned char base64Auth[128] = {0};
        size_t dlen;
        Serial.printf("[DEBUG] Auth: %s:%s\n", username, password);
        Serial.printf("[DEBUG] Payload (%d bytes): %s\n", strlen(data), data);

        mbedtls_base64_encode(base64Auth, sizeof(base64Auth), &dlen, (const unsigned char *)auth.c_str(), auth.length());
        base64Auth[dlen] = 0;

        // Header + Body
        String request = String("POST ") + path + " HTTP/1.1\r\n" +
                         "Host: " + host + "\r\n" +
                         "Authorization: Basic " + String((char *)base64Auth) + "\r\n" +
                         "Content-Type: application/json\r\n" +
                         "Content-Length: " + String(strlen(data)) + "\r\n" +
                         "Connection: close\r\n\r\n" +
                         data;

        const char *reqBuf = request.c_str();
        size_t reqLen = request.length();
        size_t written = 0;

        Serial.print("[HTTP] Sending...");
        while (written < reqLen)
        {
            ret = mbedtls_ssl_write(&ssl, (const unsigned char *)(reqBuf + written), reqLen - written);
            if (ret > 0)
                written += ret;
            else if (ret != MBEDTLS_ERR_SSL_WANT_READ && ret != MBEDTLS_ERR_SSL_WANT_WRITE)
            {
                Serial.println(" Failed!");
                goto exit;
            }
        }
        Serial.println(" Sent!");
    }

    // 7. Read Response
    {
        unsigned char buf[512];
        unsigned long timeout = millis();
        Serial.println("[HTTP] Response:");
        do
        {
            ret = mbedtls_ssl_read(&ssl, buf, sizeof(buf) - 1);
            if (ret > 0)
            {
                buf[ret] = 0;
                Serial.print((char *)buf);
                timeout = millis();
            }
            else if (ret == MBEDTLS_ERR_SSL_PEER_CLOSE_NOTIFY)
            {
                break;
            }
        } while (millis() - timeout < 5000);
        Serial.println("\n[HTTP] Done");
    }
    ret = 0; // Success

exit:
    mbedtls_ssl_close_notify(&ssl);
    ethClient.stop();
    mbedtls_ssl_free(&ssl);
    mbedtls_ssl_config_free(&conf);
    mbedtls_ctr_drbg_free(&ctr_drbg);
    mbedtls_entropy_free(&entropy);
    return (ret == 0) ? 200 : -1;
}

#endif