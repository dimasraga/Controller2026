#ifndef MBEDTLS_HANDLER_HPP
#define MBEDTLS_HANDLER_HPP

#include <Arduino.h>
#include <Ethernet.h>
#include <ArduinoJson.h>
#include "certs.h"

#include "mbedtls/platform.h"
#include "mbedtls/net_sockets.h"
#include "mbedtls/ssl.h"
#include "mbedtls/entropy.h"
#include "mbedtls/ctr_drbg.h"
#include "mbedtls/error.h"
#include "mbedtls/base64.h"

// Callback Kirim - Optimized
int eth_ssl_send(void *ctx, const unsigned char *buf, size_t len)
{
    EthernetClient *client = (EthernetClient *)ctx;
    if (!client || !client->connected())
        return MBEDTLS_ERR_NET_CONN_RESET;
    size_t totalWritten = 0;
    const size_t CHUNK_SIZE = 512;
    while (totalWritten < len)
    {
        size_t toWrite = min((size_t)CHUNK_SIZE, len - totalWritten);
        size_t written = client->write(buf + totalWritten, toWrite);

        if (written > 0)
        {
            totalWritten += written;
        }
        else
        {
            return (totalWritten > 0) ? totalWritten : MBEDTLS_ERR_SSL_WANT_WRITE;
        }

        if (totalWritten < len)
            vTaskDelay(pdMS_TO_TICKS(1));
    }
    client->flush();
    return totalWritten;
}

// Callback Terima - Optimized with timeout
int eth_ssl_recv(void *ctx, unsigned char *buf, size_t len)
{
    EthernetClient *client = (EthernetClient *)ctx;
    if (!client || !client->connected())
        return MBEDTLS_ERR_NET_CONN_RESET;

    // ✅ Adaptive timeout: pendek untuk cek awal, panjang untuk data besar
    unsigned long timeout = (len > 512) ? 30 : 15;
    unsigned long start = millis();

    while (!client->available())
    {
        if (millis() - start >= timeout)
            return MBEDTLS_ERR_SSL_WANT_READ;
        vTaskDelay(pdMS_TO_TICKS(1));
    }

    int avail = client->available();
    if (avail > 0)
    {
        int readLen = min(avail, (int)len);
        return client->read(buf, readLen);
    }

    return MBEDTLS_ERR_SSL_WANT_READ;
}

// Fungsi Utama Request - OPTIMIZED
int perform_https_request_mbedtls(EthernetClient &ethClient, const char *host, const char *path, const char *data, const char *username, const char *password)
{
    int ret;
    mbedtls_entropy_context entropy;
    mbedtls_ctr_drbg_context ctr_drbg;
    mbedtls_ssl_context ssl;
    mbedtls_ssl_config conf;
    mbedtls_x509_crt cacert;

    // 1. Init
    mbedtls_ssl_init(&ssl);
    mbedtls_ssl_config_init(&conf);
    mbedtls_x509_crt_init(&cacert);
    mbedtls_ctr_drbg_init(&ctr_drbg);
    mbedtls_entropy_init(&entropy);

    Serial.printf("\n[HTTPS] Connecting to: %s\n", host);

    // 2. Seed RNG
    const char *pers = "eth_ssl_client";
    if ((ret = mbedtls_ctr_drbg_seed(&ctr_drbg, mbedtls_entropy_func, &entropy,
                                     (const unsigned char *)pers, strlen(pers))) != 0)
    {
        Serial.printf("[TLS] RNG Seed Failed: -0x%x\n", -ret);
        goto exit;
    }

    // 3. SSL Config - Optimized settings
    // 3. SSL Config - Fully Optimized
    mbedtls_ssl_config_defaults(&conf, MBEDTLS_SSL_IS_CLIENT,
                                MBEDTLS_SSL_TRANSPORT_STREAM,
                                MBEDTLS_SSL_PRESET_DEFAULT);

    // ✅ Settings optimal
    mbedtls_ssl_conf_authmode(&conf, MBEDTLS_SSL_VERIFY_NONE);
    mbedtls_ssl_conf_rng(&conf, mbedtls_ctr_drbg_random, &ctr_drbg);
    mbedtls_ssl_conf_read_timeout(&conf, 1500); // ✅ 1.5 detik lebih optimal
    mbedtls_ssl_conf_max_frag_len(&conf, MBEDTLS_SSL_MAX_FRAG_LEN_1024);

    // ✅ Disable session tickets untuk save memory
    mbedtls_ssl_conf_session_tickets(&conf, MBEDTLS_SSL_SESSION_TICKETS_DISABLED);
    if ((ret = mbedtls_ssl_setup(&ssl, &conf)) != 0)
    {
        Serial.printf("[TLS] Setup Failed: -0x%x\n", -ret);
        goto exit;
    }

    if ((ret = mbedtls_ssl_set_hostname(&ssl, host)) != 0)
    {
        Serial.printf("[TLS] Set Hostname Failed: -0x%x\n", -ret);
        goto exit;
    }

    // 4. TCP Connect with Fast Fail
    Serial.print("[TCP] Connecting... ");
    ethClient.setTimeout(1500); // ✅ 1.5 detik lebih optimal

    if (!ethClient.connect(host, 443))
    {
        Serial.println("FAILED");
        ret = -1;
        goto exit; // ✅ Langsung exit tanpa delay
    }
    Serial.println("OK");

    // 5. TLS Handshake with timeout
    Serial.print("[TLS] Handshaking... ");
    mbedtls_ssl_set_bio(&ssl, &ethClient, eth_ssl_send, eth_ssl_recv, NULL);

    {
        unsigned long handshake_start = millis();
        while ((ret = mbedtls_ssl_handshake(&ssl)) != 0)
        {
            if (ret != MBEDTLS_ERR_SSL_WANT_READ && ret != MBEDTLS_ERR_SSL_WANT_WRITE)
            {
                Serial.printf("FAILED (-0x%x)\n", -ret);
                goto exit;
            }

            // OPTIMASI: Timeout dikurangi dari 10 detik ke 8 detik
            if (millis() - handshake_start > 2500)
            {
                Serial.println("TIMEOUT");
            }
            vTaskDelay(pdMS_TO_TICKS(1));
        }
    }
    // 6. Build and Send Request - OPTIMIZED
    {
        // Create Basic Auth
        String auth = String(username) + ":" + String(password);
        unsigned char base64Auth[128] = {0};
        size_t dlen;

        mbedtls_base64_encode(base64Auth, sizeof(base64Auth), &dlen,
                              (const unsigned char *)auth.c_str(), auth.length());
        base64Auth[dlen] = 0;

        // ✅ Pre-allocate memory untuk request
        String request;
        request.reserve(512 + strlen(data));

        // ✅ Build dengan assignment + append (lebih cepat)
        request = "POST ";
        request += path;
        request += " HTTP/1.1\r\nHost: ";
        request += host;
        request += "\r\nAuthorization: Basic ";
        request += (char *)base64Auth;
        request += "\r\nContent-Type: application/json\r\nContent-Length: ";
        request += String(strlen(data));
        request += "\r\nConnection: close\r\nUser-Agent: ESP32-TLS\r\n\r\n";
        request += data;

        // Send dengan chunking (sama seperti sebelumnya)
        Serial.print("[HTTPS] Sending... ");
        const char *reqBuf = request.c_str();
        size_t reqLen = request.length();
        size_t written = 0;

        while (written < reqLen)
        {
            ret = mbedtls_ssl_write(&ssl,
                                    (const unsigned char *)(reqBuf + written),
                                    reqLen - written);

            if (ret > 0)
            {
                written += ret;
            }
            else if (ret != MBEDTLS_ERR_SSL_WANT_READ &&
                     ret != MBEDTLS_ERR_SSL_WANT_WRITE)
            {
                Serial.printf("FAILED (-0x%x)\n", -ret);
                goto exit;
            }
            vTaskDelay(pdMS_TO_TICKS(1));
        }
        Serial.printf("OK (%d bytes)\n", written);
    }
    // 7. Read Response - OPTIMIZED with Content-Length
    {
        unsigned char buf[1024]; // ✅ Buffer lebih kecil = efisien
        String response = "";
        response.reserve(1536);

        unsigned long readStart = millis();
        int httpCode = 0;
        bool headersComplete = false;
        int contentLength = -1;
        String bodyBuffer = "";

        Serial.print("[HTTPS] Reading response... ");

        // ✅ Timeout lebih pendek
        while (millis() - readStart < 1200)
        {
            ret = mbedtls_ssl_read(&ssl, buf, sizeof(buf) - 1);

            if (ret > 0)
            {
                buf[ret] = 0;
                response += String((char *)buf);
                readStart = millis(); // Reset timeout

                // ✅ Parse headers untuk dapat Content-Length
                if (!headersComplete)
                {
                    int headerEnd = response.indexOf("\r\n\r\n");
                    if (headerEnd >= 0)
                    {
                        headersComplete = true;

                        // Extract HTTP code
                        int statusIdx = response.indexOf("HTTP/1.1 ");
                        if (statusIdx >= 0)
                        {
                            httpCode = response.substring(statusIdx + 9, statusIdx + 12).toInt();
                        }

                        // ✅ Extract Content-Length untuk tahu kapan selesai
                        int clIdx = response.indexOf("Content-Length: ");
                        if (clIdx >= 0)
                        {
                            int clEnd = response.indexOf("\r\n", clIdx);
                            contentLength = response.substring(clIdx + 16, clEnd).toInt();
                        }

                        bodyBuffer = response.substring(headerEnd + 4);
                    }
                }
                else
                {
                    bodyBuffer += String((char *)buf);

                    // ✅ Berhenti jika body sudah lengkap
                    if (contentLength > 0 && bodyBuffer.length() >= contentLength)
                    {
                        break;
                    }
                }
            }
            else if (ret == MBEDTLS_ERR_SSL_WANT_READ ||
                     ret == MBEDTLS_ERR_SSL_WANT_WRITE)
            {
                vTaskDelay(pdMS_TO_TICKS(2));
                continue;
            }
            else if (ret == MBEDTLS_ERR_SSL_PEER_CLOSE_NOTIFY || ret == 0)
            {
                break;
            }
            else
            {
                Serial.printf("Read error: -0x%x\n", -ret);
                break;
            }
        }

        Serial.println("OK");
        Serial.printf("[HTTP] Status: %d\n", httpCode);

        // ✅ Parse JSON dari bodyBuffer (bukan response utuh)
        if (headersComplete && bodyBuffer.length() > 0)
        {
            int jsonStart = bodyBuffer.indexOf('{');
            int jsonEnd = bodyBuffer.lastIndexOf('}');

            if (jsonStart >= 0 && jsonEnd > jsonStart)
            {
                String jsonStr = bodyBuffer.substring(jsonStart, jsonEnd + 1);

                StaticJsonDocument<256> doc; // ✅ Lebih kecil
                DeserializationError error = deserializeJson(doc, jsonStr);

                if (!error)
                {
                    bool isSuccess = doc["isSuccess"] | false;
                    const char *message = doc["message"] | "No message";

                    Serial.println("[Response]");
                    Serial.printf("  Success: %s\n", isSuccess ? "YES" : "NO");
                    Serial.printf("  Message: %s\n", message);

                    ret = (isSuccess && httpCode == 200) ? 0 : -1;
                }
                else
                {
                    ret = (httpCode == 200) ? 0 : -1;
                }
            }
        }
    }
exit:
    mbedtls_ssl_close_notify(&ssl);
    ethClient.stop();
    mbedtls_ssl_free(&ssl);
    mbedtls_ssl_config_free(&conf);
    mbedtls_x509_crt_free(&cacert);
    mbedtls_ctr_drbg_free(&ctr_drbg);
    mbedtls_entropy_free(&entropy);
    Serial.println("[HTTPS] Connection closed\n");
    vTaskDelay(1);

    return (ret == 0) ? 200 : -1;
}
#endif