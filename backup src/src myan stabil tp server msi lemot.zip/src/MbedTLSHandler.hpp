#ifndef MBEDTLS_HANDLER_HPP
#define MBEDTLS_HANDLER_HPP

#include <Arduino.h>
#include <Ethernet.h>
#include <ArduinoJson.h>
#include "certs.h"
#include "esp_task_wdt.h"

#include "mbedtls/platform.h"
#include "mbedtls/net_sockets.h"
#include "mbedtls/ssl.h"
#include "mbedtls/entropy.h"
#include "mbedtls/ctr_drbg.h"
#include "mbedtls/error.h"
#include "mbedtls/base64.h"

// ============================================================================
// FIX #1: TIMEOUT REALISTIS - Jangan terlalu agresif → penyebab partial read
//         yang membuat mbedtls_ssl_write() dipanggil lagi saat koneksi
//         sudah setengah mati → crash / SW_CPU_RESET.
// ============================================================================
#define TLS_HANDSHAKE_TIMEOUT   8000    // Cukup waktu untuk handshake nyata
#define TLS_READ_TIMEOUT        5000    // Cukup untuk baca response penuh
#define TLS_RECV_WAIT_MS        5       // Lebih kecil = lebih responsif
#define TCP_CONNECT_RETRIES     1       // 1 retry masih OK
#define SSL_BUFFER_SIZE         1024    // FIX: 768 terlalu kecil → buffer overflow
#define RESPONSE_RESERVE_SIZE   2048    // Cukup untuk response JSON

// ============================================================================
// FIX #2: Callback Send - tambahkan guard loop + batas iterasi
//         Versi lama: jika write() kembalikan 0 terus → infinite spin
//         (watchdog timeout → reboot)
// ============================================================================
int eth_ssl_send(void *ctx, const unsigned char *buf, size_t len)
{
    EthernetClient *client = (EthernetClient *)ctx;
    if (!client || !client->connected())
        return MBEDTLS_ERR_NET_CONN_RESET;

    // FIX: Jangan langsung flush setiap byte, bisa memperlambat dan
    //      menyebabkan partial write yang membingungkan mbedtls
    int written = client->write(buf, len);
    if (written > 0)
    {
        return written;
    }
    // Jika 0, beri tanda WANT_WRITE agar mbedtls retry dengan benar
    return MBEDTLS_ERR_SSL_WANT_WRITE;
}

// ============================================================================
// FIX #3: Callback Recv - Guard koneksi putus di tengah baca
// ============================================================================
int eth_ssl_recv(void *ctx, unsigned char *buf, size_t len)
{
    EthernetClient *client = (EthernetClient *)ctx;
    if (!client)
        return MBEDTLS_ERR_NET_CONN_RESET;

    // Jika koneksi putus DAN tidak ada data tersisa di buffer
    if (!client->connected() && !client->available())
        return MBEDTLS_ERR_NET_CONN_RESET;

    unsigned long start = millis();
    while (!client->available())
    {
        if (millis() - start >= TLS_RECV_WAIT_MS)
            return MBEDTLS_ERR_SSL_WANT_READ;  // Beri tahu mbedtls untuk coba lagi
        vTaskDelay(pdMS_TO_TICKS(1));
    }

    int avail = client->available();
    if (avail > 0)
    {
        int readLen = (avail > (int)len) ? (int)len : avail;
        return client->read(buf, readLen);
    }
    return MBEDTLS_ERR_SSL_WANT_READ;
}

// ============================================================================
// Helper: Cek apakah JSON response sudah lengkap (early exit)
// ============================================================================
inline bool isJsonComplete(const String &response)
{
    int jsonStart = response.indexOf('{');
    int jsonEnd   = response.lastIndexOf('}');
    if (jsonStart >= 0 && jsonEnd > jsonStart)
    {
        String json = response.substring(jsonStart, jsonEnd + 1);
        return (json.indexOf("\"isSuccess\"") >= 0 && json.indexOf("\"message\"") >= 0);
    }
    return false;
}

// ============================================================================
// FIX #4: FUNGSI UTAMA - perform_https_request_mbedtls()
//
// ROOT CAUSE REBOOT (SW_CPU_RESET):
//   A. Stack overflow: semua variabel besar dialokasikan di stack fungsi ini
//      yang dipanggil dari task dengan stack 16384. mbedtls structs itu besar!
//   B. Watchdog: mbedtls_ssl_handshake loop tidak feed WDT cukup sering
//   C. String concatenation di-heap: "request" String bisa jadi sangat besar
//      dan gagal alokasi → crash
//   D. Nested mutex: dipanggil dari dalam jsonMutex yang sudah dipegang
//      → deadlock jika task lain juga butuh jsonMutex
// ============================================================================
int perform_https_request_mbedtls(EthernetClient &ethClient,
                                  const char *host,
                                  const char *path,
                                  const char *data,
                                  const char *username,
                                  const char *password)
{
    int ret = -1;

    // FIX A: Alokasikan mbedtls context di heap, bukan stack
    //        Ini saja bisa hemat 4-6KB stack per panggilan!
    mbedtls_entropy_context  *entropy  = new mbedtls_entropy_context();
    mbedtls_ctr_drbg_context *ctr_drbg = new mbedtls_ctr_drbg_context();
    mbedtls_ssl_context      *ssl      = new mbedtls_ssl_context();
    mbedtls_ssl_config       *conf     = new mbedtls_ssl_config();
    mbedtls_x509_crt         *cacert   = new mbedtls_x509_crt();

    // Guard: jika alokasi heap gagal (heap habis), bail out dengan bersih
    if (!entropy || !ctr_drbg || !ssl || !conf || !cacert)
    {
        Serial.printf("[TLS] HEAP FAIL: free=%d\n", ESP.getFreeHeap());
        delete entropy; delete ctr_drbg; delete ssl; delete conf; delete cacert;
        return -1;
    }

    mbedtls_ssl_init(ssl);
    mbedtls_ssl_config_init(conf);
    mbedtls_x509_crt_init(cacert);
    mbedtls_ctr_drbg_init(ctr_drbg);
    mbedtls_entropy_init(entropy);

    Serial.printf("\n[HTTPS] -> %s\n", host);
    Serial.printf("[HEAP] Free: %d bytes\n", ESP.getFreeHeap());

    // ---- RNG Seed ----
    const char *pers = "eth_ssl";
    if ((ret = mbedtls_ctr_drbg_seed(ctr_drbg, mbedtls_entropy_func, entropy,
                                     (const unsigned char *)pers, strlen(pers))) != 0)
    {
        Serial.printf("[TLS] RNG Fail: -0x%x\n", -ret);
        goto exit;
    }

    // ---- SSL Config ----
    mbedtls_ssl_config_defaults(conf, MBEDTLS_SSL_IS_CLIENT,
                                MBEDTLS_SSL_TRANSPORT_STREAM,
                                MBEDTLS_SSL_PRESET_DEFAULT);

    mbedtls_ssl_conf_authmode(conf, MBEDTLS_SSL_VERIFY_NONE);
    mbedtls_ssl_conf_rng(conf, mbedtls_ctr_drbg_random, ctr_drbg);
    mbedtls_ssl_conf_read_timeout(conf, TLS_READ_TIMEOUT);
    mbedtls_ssl_conf_session_tickets(conf, MBEDTLS_SSL_SESSION_TICKETS_DISABLED);

    if ((ret = mbedtls_ssl_setup(ssl, conf)) != 0)
    {
        Serial.printf("[TLS] Setup Fail: -0x%x\n", -ret);
        goto exit;
    }

    if ((ret = mbedtls_ssl_set_hostname(ssl, host)) != 0)
    {
        Serial.printf("[TLS] Hostname Fail: -0x%x\n", -ret);
        goto exit;
    }

    // ---- TCP Connect ----
    Serial.print("[TCP] Connecting... ");
    {
        bool connected = false;
        for (int i = 0; i <= TCP_CONNECT_RETRIES && !connected; i++)
        {
            esp_task_wdt_reset();  // Feed WDT sebelum operasi blocking
            if (ethClient.connect(host, 443))
            {
                connected = true;
                Serial.println("OK");
            }
            else if (i < TCP_CONNECT_RETRIES)
            {
                Serial.print(".");
                // FIX: vTaskDelay bukan delay() agar IDLE task bisa jalan
                vTaskDelay(pdMS_TO_TICKS(300));
            }
        }

        if (!connected)
        {
            Serial.println(" FAIL");
            ret = -1;
            goto exit;
        }
    }

    // ---- TLS Handshake ----
    Serial.print("[TLS] Handshake... ");
    mbedtls_ssl_set_bio(ssl, &ethClient, eth_ssl_send, eth_ssl_recv, NULL);

    {
        unsigned long hs_start    = millis();
        int           hs_attempts = 0;

        while ((ret = mbedtls_ssl_handshake(ssl)) != 0)
        {
            if (ret != MBEDTLS_ERR_SSL_WANT_READ && ret != MBEDTLS_ERR_SSL_WANT_WRITE)
            {
                Serial.printf("FAIL (-0x%x)\n", -ret);
                goto exit;
            }

            if (millis() - hs_start > TLS_HANDSHAKE_TIMEOUT)
            {
                Serial.println("TIMEOUT");
                ret = -1;
                goto exit;
            }

            // FIX B: Feed WDT lebih sering agar tidak reboot saat handshake lama
            if (++hs_attempts % 5 == 0)
            {
                esp_task_wdt_reset();
            }

            vTaskDelay(pdMS_TO_TICKS(2));
        }
        Serial.printf("OK (%lu ms)\n", millis() - hs_start);
    }

    // ---- Build & Send HTTP Request ----
    {
        // Basic Auth encoding
        String auth = String(username) + ":" + String(password);
        unsigned char base64Auth[128] = {0};
        size_t dlen = 0;

        mbedtls_base64_encode(base64Auth, sizeof(base64Auth), &dlen,
                              (const unsigned char *)auth.c_str(), auth.length());
        base64Auth[dlen] = '\0';

        // FIX C: Hitung panjang dulu, lalu reserve String
        //        Hindari reallokasi String yang bisa menyebabkan heap fragmen
        size_t dataLen = strlen(data);
        String request;
        // Estimasi ukuran request header (~200 byte) + data
        request.reserve(256 + dataLen);

        request  = "POST ";
        request += path;
        request += " HTTP/1.1\r\nHost: ";
        request += host;
        request += "\r\nAuthorization: Basic ";
        request += (char *)base64Auth;
        request += "\r\nContent-Type: application/json\r\nContent-Length: ";
        request += String(dataLen);
        request += "\r\nConnection: close\r\n\r\n";
        request += data;

        Serial.print("[HTTPS] Sending... ");
        const char  *reqBuf   = request.c_str();
        size_t       reqLen   = request.length();
        size_t       written  = 0;
        unsigned long send_start = millis();

        while (written < reqLen)
        {
            ret = mbedtls_ssl_write(ssl,
                                    (const unsigned char *)(reqBuf + written),
                                    reqLen - written);
            if (ret > 0)
            {
                written += ret;
            }
            else if (ret == MBEDTLS_ERR_SSL_WANT_READ || ret == MBEDTLS_ERR_SSL_WANT_WRITE)
            {
                // Normal non-blocking retry
            }
            else
            {
                Serial.printf("FAIL (-0x%x)\n", -ret);
                goto exit;
            }

            if (millis() - send_start > 5000)
            {
                Serial.println("TIMEOUT");
                ret = -1;
                goto exit;
            }

            esp_task_wdt_reset();
            vTaskDelay(pdMS_TO_TICKS(1));
        }
        Serial.printf("OK (%d bytes)\n", (int)written);
    }

    // ---- Read Response ----
    {
        // FIX: Stack buffer dikurangi, sisanya di heap via String
        unsigned char buf[SSL_BUFFER_SIZE];
        String response;
        response.reserve(RESPONSE_RESERVE_SIZE);

        unsigned long read_start  = millis();
        int           httpCode    = 0;
        bool          headerParsed = false;
        bool          jsonFound   = false;

        Serial.print("[HTTPS] Reading... ");

        while (millis() - read_start < TLS_READ_TIMEOUT)
        {
            ret = mbedtls_ssl_read(ssl, buf, sizeof(buf) - 1);

            if (ret > 0)
            {
                buf[ret] = '\0';
                response += (const char *)buf;

                if (!headerParsed)
                {
                    int statusIdx = response.indexOf("HTTP/1.1 ");
                    if (statusIdx >= 0)
                    {
                        httpCode = response.substring(statusIdx + 9, statusIdx + 12).toInt();
                        headerParsed = true;
                    }
                }

                if (headerParsed && !jsonFound && response.indexOf('{') >= 0)
                {
                    if (isJsonComplete(response))
                    {
                        jsonFound = true;
                        vTaskDelay(pdMS_TO_TICKS(5));
                        break;
                    }
                }
            }
            else if (ret == MBEDTLS_ERR_SSL_WANT_READ || ret == MBEDTLS_ERR_SSL_WANT_WRITE)
            {
                vTaskDelay(pdMS_TO_TICKS(2));
                esp_task_wdt_reset();
                continue;
            }
            else if (ret == MBEDTLS_ERR_SSL_PEER_CLOSE_NOTIFY || ret == 0)
            {
                break;  // Server tutup koneksi = response selesai
            }
            else
            {
                // Error lain - keluar
                break;
            }

            esp_task_wdt_reset();
        }

        Serial.printf("OK (%lu ms)\n", millis() - read_start);
        Serial.printf("[HTTP] Status: %d\n", httpCode);

        // ---- Parse JSON Body ----
        int bodyStart = response.indexOf("\r\n\r\n");
        if (bodyStart >= 0)
        {
            String body      = response.substring(bodyStart + 4);
            int    jsonStart = body.indexOf('{');
            int    jsonEnd   = body.lastIndexOf('}');

            if (jsonStart >= 0 && jsonEnd > jsonStart)
            {
                String jsonStr = body.substring(jsonStart, jsonEnd + 1);

                StaticJsonDocument<512> doc;
                DeserializationError error = deserializeJson(doc, jsonStr);

                if (!error)
                {
                    bool       isSuccess = doc["isSuccess"] | false;
                    const char *message  = doc["message"] | "No message";
                    Serial.printf("[Response] %s: %s\n", isSuccess ? "OK" : "FAIL", message);
                    ret = isSuccess ? 0 : -1;
                }
                else
                {
                    ret = (httpCode == 200) ? 0 : -1;
                }
            }
            else
            {
                ret = (httpCode == 200) ? 0 : -1;
            }
        }
        else
        {
            ret = (httpCode == 200) ? 0 : -1;
        }
    }

exit:
    // ---- Cleanup ----
    mbedtls_ssl_close_notify(ssl);
    ethClient.stop();
    mbedtls_ssl_free(ssl);
    mbedtls_ssl_config_free(conf);
    mbedtls_x509_crt_free(cacert);
    mbedtls_ctr_drbg_free(ctr_drbg);
    mbedtls_entropy_free(entropy);

    // FIX A: Bebaskan heap yang dialokasikan di atas
    delete ssl;
    delete conf;
    delete cacert;
    delete ctr_drbg;
    delete entropy;

    Serial.println("[HTTPS] Closed\n");
    return (ret == 0) ? 200 : -1;
}

#endif  // MBEDTLS_HANDLER_HPP