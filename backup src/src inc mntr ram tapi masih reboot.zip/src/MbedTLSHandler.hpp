#ifndef MBEDTLS_HANDLER_HPP
#define MBEDTLS_HANDLER_HPP

#include <Arduino.h>
#include <Ethernet.h>
#include <ArduinoJson.h>
#include "certs.h"
#include "esp_task_wdt.h"

#include "mbedtls/platform.h"
#include "mbedtls/net_sockets.h"
#include "mbedtls/ssl.h"
#include "mbedtls/entropy.h"
#include "mbedtls/ctr_drbg.h"
#include "mbedtls/error.h"
#include "mbedtls/base64.h"

// ============================================================================
// OPTIMASI 1: KONFIGURASI PERFORMA TINGGI
// ============================================================================
#define TLS_HANDSHAKE_TIMEOUT 2000      // Turun dari 3000ms ke 2000ms
#define TLS_READ_TIMEOUT 1500           // Turun dari 2500ms ke 1500ms
#define TLS_RECV_WAIT_MS 30             // Turun dari 50ms ke 30ms
#define TCP_CONNECT_RETRIES 1           // Turun dari 2 ke 1 (cepat fail)
#define SSL_BUFFER_SIZE 768             // Turun dari 1024 ke 768
#define RESPONSE_RESERVE_SIZE 1536      // Turun dari 2048 ke 1536

// ============================================================================
// OPTIMASI 2: Callback Kirim - Non-blocking dengan timeout lebih ketat
// ============================================================================
int eth_ssl_send(void *ctx, const unsigned char *buf, size_t len)
{
    EthernetClient *client = (EthernetClient *)ctx;
    if (!client || !client->connected())
        return MBEDTLS_ERR_NET_CONN_RESET;

    size_t written = client->write(buf, len);
    if (written > 0)
    {
        client->flush();
        return written;
    }
    return MBEDTLS_ERR_SSL_WANT_WRITE;
}

// ============================================================================
// OPTIMASI 3: Callback Terima - Timeout lebih agresif
// ============================================================================
int eth_ssl_recv(void *ctx, unsigned char *buf, size_t len)
{
    EthernetClient *client = (EthernetClient *)ctx;
    if (!client || !client->connected())
        return MBEDTLS_ERR_NET_CONN_RESET;
    
    unsigned long start = millis();
    while (!client->available() && millis() - start < TLS_RECV_WAIT_MS)
    {
        vTaskDelay(pdMS_TO_TICKS(1));
    }
    
    int avail = client->available();
    if (avail > 0)
    {
        int readLen = (avail > (int)len) ? len : avail;
        return client->read(buf, readLen);
    }
    return MBEDTLS_ERR_SSL_WANT_READ;
}

// ============================================================================
// OPTIMASI 4: Fungsi helper untuk early exit pada response
// ============================================================================
inline bool isJsonComplete(const String &response)
{
    int jsonStart = response.indexOf('{');
    int jsonEnd = response.lastIndexOf('}');
    
    if (jsonStart >= 0 && jsonEnd > jsonStart)
    {
        // Cek apakah ada "isSuccess" dan "message" - indikator response lengkap
        String json = response.substring(jsonStart, jsonEnd + 1);
        return (json.indexOf("\"isSuccess\"") >= 0 && json.indexOf("\"message\"") >= 0);
    }
    return false;
}

// ============================================================================
// OPTIMASI 5: Fungsi Utama Request - SUPER OPTIMIZED
// ============================================================================
int perform_https_request_mbedtls(EthernetClient &ethClient, const char *host, const char *path, const char *data, const char *username, const char *password)
{
    int ret;
    mbedtls_entropy_context entropy;
    mbedtls_ctr_drbg_context ctr_drbg;
    mbedtls_ssl_context ssl;
    mbedtls_ssl_config conf;
    mbedtls_x509_crt cacert;

    // Init
    mbedtls_ssl_init(&ssl);
    mbedtls_ssl_config_init(&conf);
    mbedtls_x509_crt_init(&cacert);
    mbedtls_ctr_drbg_init(&ctr_drbg);
    mbedtls_entropy_init(&entropy);

    Serial.printf("\n[HTTPS] → %s\n", host);

    // ========================================================================
    // OPTIMASI 6: RNG Seed - minimal error checking
    // ========================================================================
    const char *pers = "eth_ssl";
    if ((ret = mbedtls_ctr_drbg_seed(&ctr_drbg, mbedtls_entropy_func, &entropy,
                                     (const unsigned char *)pers, strlen(pers))) != 0)
    {
        Serial.printf("[TLS] RNG Fail: -0x%x\n", -ret);
        goto exit;
    }

    // ========================================================================
    // OPTIMASI 7: SSL Config - setting minimal untuk speed
    // ========================================================================
    mbedtls_ssl_config_defaults(&conf, MBEDTLS_SSL_IS_CLIENT,
                                MBEDTLS_SSL_TRANSPORT_STREAM,
                                MBEDTLS_SSL_PRESET_DEFAULT);
    
    mbedtls_ssl_conf_authmode(&conf, MBEDTLS_SSL_VERIFY_NONE);  // Skip cert verification
    mbedtls_ssl_conf_rng(&conf, mbedtls_ctr_drbg_random, &ctr_drbg);
    mbedtls_ssl_conf_read_timeout(&conf, TLS_READ_TIMEOUT);
    
    // CRITICAL: Disable session tickets untuk speed (trade memory for speed)
    mbedtls_ssl_conf_session_tickets(&conf, MBEDTLS_SSL_SESSION_TICKETS_DISABLED);

    if ((ret = mbedtls_ssl_setup(&ssl, &conf)) != 0)
    {
        Serial.printf("[TLS] Setup Fail: -0x%x\n", -ret);
        goto exit;
    }

    if ((ret = mbedtls_ssl_set_hostname(&ssl, host)) != 0)
    {
        Serial.printf("[TLS] Hostname Fail: -0x%x\n", -ret);
        goto exit;
    }

    // ========================================================================
    // OPTIMASI 8: TCP Connect - fast fail, minimal retries
    // ========================================================================
    Serial.print("[TCP] Connecting... ");
    {
        bool connected = false;
        for (int i = 0; i <= TCP_CONNECT_RETRIES && !connected; i++)
        {
            if (ethClient.connect(host, 443))
            {
                connected = true;
                Serial.println("✓");
            }
            else
            {
                if (i < TCP_CONNECT_RETRIES)
                {
                    Serial.print(".");
                    vTaskDelay(pdMS_TO_TICKS(300)); // Turun dari 500ms
                }
            }
        }
        
        if (!connected)
        {
            Serial.println(" ✗");
            ret = -1;
            goto exit;
        }
    }

    // ========================================================================
    // OPTIMASI 9: TLS Handshake - timeout super agresif
    // ========================================================================
    Serial.print("[TLS] Handshake... ");
    mbedtls_ssl_set_bio(&ssl, &ethClient, eth_ssl_send, eth_ssl_recv, NULL);

    {
        unsigned long hs_start = millis();
        int hs_attempts = 0;
        
        while ((ret = mbedtls_ssl_handshake(&ssl)) != 0)
        {
            if (ret != MBEDTLS_ERR_SSL_WANT_READ && ret != MBEDTLS_ERR_SSL_WANT_WRITE)
            {
                Serial.printf("✗ (-0x%x)\n", -ret);
                goto exit;
            }

            // CRITICAL: Aggressive timeout untuk prevent watchdog
            if (millis() - hs_start > TLS_HANDSHAKE_TIMEOUT)
            {
                Serial.println("✗ Timeout");
                ret = -1;
                goto exit;
            }
            
            // Feed watchdog setiap 10 attempts (bukan setiap loop)
            if (++hs_attempts % 10 == 0)
            {
                esp_task_wdt_reset();
            }
            
            vTaskDelay(pdMS_TO_TICKS(1));
        }
        Serial.printf("✓ (%lums)\n", millis() - hs_start);
    }

    // ========================================================================
    // OPTIMASI 10: Build Request - pre-calculated lengths
    // ========================================================================
    {
        // Basic Auth encoding
        String auth = String(username) + ":" + String(password);
        unsigned char base64Auth[128] = {0};
        size_t dlen;

        mbedtls_base64_encode(base64Auth, sizeof(base64Auth), &dlen,
                              (const unsigned char *)auth.c_str(), auth.length());
        base64Auth[dlen] = 0;

        // Build HTTP Request - minimal headers
        size_t dataLen = strlen(data);
        String request = String("POST ") + path + " HTTP/1.1\r\n" +
                         "Host: " + host + "\r\n" +
                         "Authorization: Basic " + String((char *)base64Auth) + "\r\n" +
                         "Content-Type: application/json\r\n" +
                         "Content-Length: " + String(dataLen) + "\r\n" +
                         "Connection: close\r\n" +
                         "\r\n" +
                         data;

        // ====================================================================
        // OPTIMASI 11: Send Request - batch write
        // ====================================================================
        Serial.print("[HTTPS] Sending... ");
        const char *reqBuf = request.c_str();
        size_t reqLen = request.length();
        size_t written = 0;
        unsigned long send_start = millis();

        while (written < reqLen)
        {
            ret = mbedtls_ssl_write(&ssl, (const unsigned char *)(reqBuf + written), reqLen - written);
            if (ret > 0)
            {
                written += ret;
            }
            else if (ret != MBEDTLS_ERR_SSL_WANT_READ && ret != MBEDTLS_ERR_SSL_WANT_WRITE)
            {
                Serial.printf("✗ (-0x%x)\n", -ret);
                goto exit;
            }
            
            // Timeout check
            if (millis() - send_start > 2000)
            {
                Serial.println("✗ Timeout");
                ret = -1;
                goto exit;
            }
            
            esp_task_wdt_reset();
            vTaskDelay(pdMS_TO_TICKS(1));
        }
        Serial.printf("✓ (%d bytes)\n", written);
    }

    // ========================================================================
    // OPTIMASI 12: Read Response - ULTRA FAST dengan early exit
    // ========================================================================
    {
        unsigned char buf[SSL_BUFFER_SIZE];
        String response = "";
        response.reserve(RESPONSE_RESERVE_SIZE);
        unsigned long read_start = millis();
        int httpCode = 0;
        bool headerParsed = false;
        bool jsonFound = false;

        Serial.print("[HTTPS] Reading... ");

        while (millis() - read_start < TLS_READ_TIMEOUT)
        {
            ret = mbedtls_ssl_read(&ssl, buf, sizeof(buf) - 1);

            if (ret > 0)
            {
                buf[ret] = 0;
                response += String((char *)buf);
                
                // ============================================================
                // CRITICAL: Parse HTTP status ASAP
                // ============================================================
                if (!headerParsed && response.indexOf("HTTP/1.1") >= 0)
                {
                    int statusIdx = response.indexOf("HTTP/1.1 ");
                    if (statusIdx >= 0)
                    {
                        httpCode = response.substring(statusIdx + 9, statusIdx + 12).toInt();
                        headerParsed = true;
                    }
                }
                
                // ============================================================
                // CRITICAL: Early exit jika JSON sudah lengkap
                // ============================================================
                if (headerParsed && !jsonFound && response.indexOf('{') >= 0)
                {
                    if (isJsonComplete(response))
                    {
                        jsonFound = true;
                        // Tunggu sebentar untuk buffer terakhir, lalu exit
                        vTaskDelay(pdMS_TO_TICKS(10));
                        break;
                    }
                }
            }
            else if (ret == MBEDTLS_ERR_SSL_WANT_READ || ret == MBEDTLS_ERR_SSL_WANT_WRITE)
            {
                vTaskDelay(pdMS_TO_TICKS(2));
                continue;
            }
            else if (ret == MBEDTLS_ERR_SSL_PEER_CLOSE_NOTIFY || ret == 0)
            {
                break;
            }
            else
            {
                // Error lain, langsung exit
                break;
            }
            
            // Feed watchdog setiap iterasi
            esp_task_wdt_reset();
        }
        
        unsigned long read_time = millis() - read_start;
        Serial.printf("✓ (%lums)\n", read_time);

        // ====================================================================
        // OPTIMASI 13: Minimal JSON parsing
        // ====================================================================
        Serial.printf("[HTTP] Status: %d\n", httpCode);

        // Extract JSON body
        int bodyStart = response.indexOf("\r\n\r\n");
        if (bodyStart >= 0)
        {
            String body = response.substring(bodyStart + 4);
            int jsonStart = body.indexOf('{');
            int jsonEnd = body.lastIndexOf('}');

            if (jsonStart >= 0 && jsonEnd > jsonStart)
            {
                String jsonStr = body.substring(jsonStart, jsonEnd + 1);

                // Parse JSON dengan StaticJsonDocument (lebih cepat dari Dynamic)
                StaticJsonDocument<384> doc;  // Turun dari 512
                DeserializationError error = deserializeJson(doc, jsonStr);

                if (!error)
                {
                    bool isSuccess = doc["isSuccess"] | false;
                    const char *message = doc["message"] | "No message";

                    Serial.printf("[Response] %s: %s\n", 
                                  isSuccess ? "✓" : "✗", message);

                    ret = isSuccess ? 0 : -1;
                }
                else
                {
                    // Jika parse gagal, anggap sukses jika HTTP 200
                    ret = (httpCode == 200) ? 0 : -1;
                }
            }
            else
            {
                ret = (httpCode == 200) ? 0 : -1;
            }
        }
        else
        {
            ret = (httpCode == 200) ? 0 : -1;
        }
    }

exit:
    // ========================================================================
    // OPTIMASI 14: Fast cleanup
    // ========================================================================
    mbedtls_ssl_close_notify(&ssl);
    ethClient.stop();
    mbedtls_ssl_free(&ssl);
    mbedtls_ssl_config_free(&conf);
    mbedtls_x509_crt_free(&cacert);
    mbedtls_ctr_drbg_free(&ctr_drbg);
    mbedtls_entropy_free(&entropy);
    
    Serial.println("[HTTPS] Closed\n");

    return (ret == 0) ? 200 : -1;
}

#endif