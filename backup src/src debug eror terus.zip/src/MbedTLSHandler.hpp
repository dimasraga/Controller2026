#ifndef MBEDTLS_HANDLER_HPP
#define MBEDTLS_HANDLER_HPP

#include <Arduino.h>
#include <Ethernet.h>
#include <ArduinoJson.h>
#include "esp_task_wdt.h"

#include "mbedtls/platform.h"
#include "mbedtls/net_sockets.h"
#include "mbedtls/ssl.h"
#include "mbedtls/entropy.h"
#include "mbedtls/ctr_drbg.h"
#include "mbedtls/error.h"
#include "mbedtls/base64.h"

// --- Tuning Constants ---
#define TLS_HANDSHAKE_TIMEOUT 8000U
#define TLS_READ_TIMEOUT 6000U
#define TLS_WRITE_TIMEOUT 5000U
#define TLS_RECV_WAIT_MS 2U
#define TCP_CONNECT_RETRIES 1
#define SSL_BUFFER_SIZE 1536U
#define BASE64_AUTH_SIZE 192U
#define RESPONSE_RESERVE_SIZE 2048U

static int eth_ssl_send(void *ctx, const unsigned char *buf, size_t len)
{
    EthernetClient *client = static_cast<EthernetClient *>(ctx);
    if (!client || !client->connected())
        return MBEDTLS_ERR_NET_CONN_RESET;
    int written = client->write(buf, len);
    if (written > 0)
        return written;
    return MBEDTLS_ERR_SSL_WANT_WRITE;
}

// Callback Recv (Optimized)
static int eth_ssl_recv(void *ctx, unsigned char *buf, size_t len)
{
    EthernetClient *client = static_cast<EthernetClient *>(ctx);
    if (!client)
        return MBEDTLS_ERR_NET_CONN_RESET;

    if (client->available() > 0)
    {
        int avail = client->available();
        int readLen = (avail > (int)len) ? (int)len : avail;
        return client->read(buf, readLen);
    }

    if (!client->connected())
        return MBEDTLS_ERR_NET_CONN_RESET;

    vTaskDelay(pdMS_TO_TICKS(TLS_RECV_WAIT_MS));
    return MBEDTLS_ERR_SSL_WANT_READ;
}

// JSON Checker (Efficient)
static inline bool isJsonComplete(const String &response)
{
    // Optimasi: Cek dulu apakah karakter terakhir adalah '}' sebelum scan isi
    // Mencegah scan string panjang yang belum selesai
    char lastChar = response.charAt(response.length() - 1);
    if (lastChar != '}')
        return false;

    int jsonStart = response.indexOf('{');
    if (jsonStart < 0)
        return false;

    int jsonEnd = response.lastIndexOf('}');
    if (jsonEnd <= jsonStart)
        return false;

    // Cek field kunci untuk memastikan validitas
    return (response.indexOf("\"isSuccess\"", jsonStart) > 0 &&
            response.indexOf("\"message\"", jsonStart) > 0);
}

int perform_https_request_mbedtls(EthernetClient &ethClient,
                                  const char *host,
                                  const char *path,
                                  const char *data,
                                  const char *username,
                                  const char *password)
{
    int ret = -1;

    // 1. Heap Allocation
    mbedtls_entropy_context *entropy = new mbedtls_entropy_context();
    mbedtls_ctr_drbg_context *ctr_drbg = new mbedtls_ctr_drbg_context();
    mbedtls_ssl_context *ssl = new mbedtls_ssl_context();
    mbedtls_ssl_config *conf = new mbedtls_ssl_config();
    mbedtls_x509_crt *cacert = new mbedtls_x509_crt();

    if (!entropy || !ctr_drbg || !ssl || !conf || !cacert)
    {
        Serial.println(F("[TLS] HEAP ALLOC FAIL"));
        delete entropy;
        delete ctr_drbg;
        delete ssl;
        delete conf;
        delete cacert;
        return -1;
    }

    mbedtls_ssl_init(ssl);
    mbedtls_ssl_config_init(conf);
    mbedtls_x509_crt_init(cacert);
    mbedtls_ctr_drbg_init(ctr_drbg);
    mbedtls_entropy_init(entropy);

    // 2. Setup
    const char *pers = "eth_tls";
    if (mbedtls_ctr_drbg_seed(ctr_drbg, mbedtls_entropy_func, entropy, (const unsigned char *)pers, strlen(pers)) != 0)
    {
        goto cleanup;
    }

    mbedtls_ssl_config_defaults(conf, MBEDTLS_SSL_IS_CLIENT, MBEDTLS_SSL_TRANSPORT_STREAM, MBEDTLS_SSL_PRESET_DEFAULT);
    mbedtls_ssl_conf_authmode(conf, MBEDTLS_SSL_VERIFY_NONE);
    mbedtls_ssl_conf_rng(conf, mbedtls_ctr_drbg_random, ctr_drbg);
    mbedtls_ssl_conf_session_tickets(conf, MBEDTLS_SSL_SESSION_TICKETS_DISABLED); // Wajib untuk W5500

    if (mbedtls_ssl_setup(ssl, conf) != 0 || mbedtls_ssl_set_hostname(ssl, host) != 0)
    {
        goto cleanup;
    }

    // 3. TCP Connect
    // Serial.print(F("[TCP] Conn...")); // Silent Mode
    {
        bool connected = false;
        for (int i = 0; i <= TCP_CONNECT_RETRIES && !connected; i++)
        {
            esp_task_wdt_reset();
            if (ethClient.connect(host, 443))
                connected = true;
            else if (i < TCP_CONNECT_RETRIES)
                vTaskDelay(pdMS_TO_TICKS(200));
        }
        if (!connected)
        {
            Serial.println(F("[TCP] Connect Failed"));
            goto cleanup;
        }
    }

    // 4. TLS Handshake
    mbedtls_ssl_set_bio(ssl, &ethClient, eth_ssl_send, eth_ssl_recv, NULL);
    {
        unsigned long hs_start = millis();
        while ((ret = mbedtls_ssl_handshake(ssl)) != 0)
        {
            if (ret != MBEDTLS_ERR_SSL_WANT_READ && ret != MBEDTLS_ERR_SSL_WANT_WRITE)
            {
                Serial.printf("[TLS] Handshake Err: -0x%04X\n", -ret);
                goto cleanup;
            }
            if (millis() - hs_start > TLS_HANDSHAKE_TIMEOUT)
            {
                Serial.println(F("[TLS] Handshake Timeout"));
                goto cleanup;
            }
            esp_task_wdt_reset();
            vTaskDelay(pdMS_TO_TICKS(2));
        }
    }

    // 5. Build & Send Request
    {
        unsigned char base64Auth[BASE64_AUTH_SIZE] = {};
        size_t authLen = 0;
        char authRaw[128];
        snprintf(authRaw, sizeof(authRaw), "%s:%s", username, password);
        mbedtls_base64_encode(base64Auth, sizeof(base64Auth), &authLen, (const unsigned char *)authRaw, strlen(authRaw));

        String request;
        request.reserve(300 + strlen(data));
        request = "POST ";
        request += path;
        request += " HTTP/1.1\r\n";
        request += "Host: ";
        request += host;
        request += "\r\n";
        request += "Authorization: Basic ";
        request += (char *)base64Auth;
        request += "\r\n";
        request += "Content-Type: application/json\r\n";
        request += "Content-Length: ";
        request += String(strlen(data));
        request += "\r\n";
        request += "Connection: close\r\n\r\n";
        request += data;

        const char *p = request.c_str();
        size_t left = request.length();
        unsigned long send_t = millis();

        while (left > 0)
        {
            ret = mbedtls_ssl_write(ssl, (const unsigned char *)p, left);
            if (ret > 0)
            {
                p += ret;
                left -= ret;
            }
            else if (ret != MBEDTLS_ERR_SSL_WANT_READ && ret != MBEDTLS_ERR_SSL_WANT_WRITE)
            {
                Serial.printf("[TLS] Write Err: -0x%04X\n", -ret);
                goto cleanup;
            }
            if (millis() - send_t > TLS_WRITE_TIMEOUT)
                goto cleanup;
            esp_task_wdt_reset();
        }
    }

    // 6. Read Response
    {
        unsigned char buf[SSL_BUFFER_SIZE];
        String response;
        response.reserve(RESPONSE_RESERVE_SIZE);
        unsigned long read_t = millis();
        bool headerDone = false;

        while (millis() - read_t < TLS_READ_TIMEOUT)
        {
            ret = mbedtls_ssl_read(ssl, buf, sizeof(buf) - 1);

            if (ret > 0)
            {
                buf[ret] = 0;
                response += (char *)buf; // Safe concat

                if (!headerDone && response.indexOf("\r\n\r\n") >= 0)
                    headerDone = true;

                // Optimasi JSON Check: Cek hanya jika header sudah lewat & karakter terakhir '}'
                if (headerDone && isJsonComplete(response))
                    break;
            }
            else if (ret == MBEDTLS_ERR_SSL_PEER_CLOSE_NOTIFY || ret == 0)
            {
                break; // Connection closed gracefully
            }
            else if (ret != MBEDTLS_ERR_SSL_WANT_READ && ret != MBEDTLS_ERR_SSL_WANT_WRITE)
            {
                break; // Error
            }
            esp_task_wdt_reset();
        }

        // 7. Parse Body
        int jsonStart = response.indexOf('{');
        int jsonEnd = response.lastIndexOf('}');
        if (jsonStart >= 0 && jsonEnd > jsonStart)
        {
            StaticJsonDocument<512> doc;
            DeserializationError err = deserializeJson(doc, response.substring(jsonStart, jsonEnd + 1));

            if (!err)
            {
                bool isSuccess = doc["isSuccess"] | false;
                ret = isSuccess ? 0 : -1;
            }
            else
            {
                ret = -1; // JSON Malformed
            }
        }
        else
        {
            ret = (response.indexOf("HTTP/1.1 20") >= 0) ? 0 : -1;
        }
    }

cleanup:
    mbedtls_ssl_close_notify(ssl);
    ethClient.stop();

    // Cleanup Heap
    mbedtls_ssl_free(ssl);
    mbedtls_ssl_config_free(conf);
    mbedtls_x509_crt_free(cacert);
    mbedtls_ctr_drbg_free(ctr_drbg);
    mbedtls_entropy_free(entropy);
    delete ssl;
    delete conf;
    delete cacert;
    delete ctr_drbg;
    delete entropy;

    return (ret == 0) ? 200 : -1;
}

#endif // MBEDTLS_HANDLER_HPP