#ifndef SYSTEM_MONITOR_HPP
#define SYSTEM_MONITOR_HPP

#include <Arduino.h>
#include "esp_system.h"
#include "esp_task_wdt.h"
#include "esp_chip_info.h"
#include "soc/rtc.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

struct SystemMetrics
{
    uint32_t freeHeap;
    uint32_t totalHeap;
    uint32_t minFreeHeap;
    uint32_t usedHeap;
    float heapUsagePercent;
    uint32_t freePSRAM;
    uint32_t totalPSRAM;
    uint32_t cpuFreqMHz;
    uint32_t apbFreqHz;
    uint8_t numCores;
    uint32_t numTasks;
    uint32_t stackHighWaterMark;
    uint32_t uptimeSeconds;
    uint32_t freeSketchSpace;
    uint32_t sketchSize;
};

class SystemMonitor
{
private:
    SystemMetrics beforeMetrics;
    SystemMetrics afterMetrics;
    unsigned long startTime;
    bool isMonitoring;

    void captureMetrics(SystemMetrics &metrics)
    {
        metrics.freeHeap = ESP.getFreeHeap();
        metrics.totalHeap = ESP.getHeapSize();
        metrics.minFreeHeap = ESP.getMinFreeHeap();
        metrics.usedHeap = metrics.totalHeap - metrics.freeHeap;
        metrics.heapUsagePercent = ((float)metrics.usedHeap / (float)metrics.totalHeap) * 100.0f;
        metrics.freePSRAM = ESP.getFreePsram();
        metrics.totalPSRAM = ESP.getPsramSize();

        esp_chip_info_t chip_info;
        esp_chip_info(&chip_info);

        metrics.cpuFreqMHz = ESP.getCpuFreqMHz();
        metrics.apbFreqHz = rtc_clk_apb_freq_get();
        metrics.numCores = chip_info.cores;
        metrics.numTasks = uxTaskGetNumberOfTasks();
        metrics.stackHighWaterMark = uxTaskGetStackHighWaterMark(NULL);
        metrics.uptimeSeconds = millis() / 1000;
        metrics.freeSketchSpace = ESP.getFreeSketchSpace();
        metrics.sketchSize = ESP.getSketchSize();
    }

    String formatBytes(uint32_t bytes)
    {
        if (bytes < 1024)
        {
            return String(bytes) + " B";
        }
        else if (bytes < 1024 * 1024)
        {
            return String(bytes / 1024.0, 2) + " KB";
        }
        else
        {
            return String(bytes / (1024.0 * 1024.0), 2) + " MB";
        }
    }

public:
    SystemMonitor() : isMonitoring(false) {}

    void begin()
    {
        startTime = millis();
        captureMetrics(beforeMetrics);
        isMonitoring = true;
    }

    void end()
    {
        if (!isMonitoring)
            return;

        captureMetrics(afterMetrics);
        isMonitoring = false;
        printComparison();
    }

    void printCurrent()
    {
        SystemMetrics c;
        captureMetrics(c);

        Serial.println();
        Serial.println("CPU & PROCESSOR:");
        Serial.printf("  CPU Frequency    : %u MHz\n", c.cpuFreqMHz);
        Serial.printf("  APB Frequency    : %.2f MHz\n", c.apbFreqHz / 1000000.0f);
        Serial.printf("  Number of Cores  : %u\n", c.numCores);
        Serial.println();
        Serial.println("MEMORY (HEAP):");
        Serial.printf("  Total Heap       : %s\n", formatBytes(c.totalHeap).c_str());
        Serial.printf("  Free Heap        : %s\n", formatBytes(c.freeHeap).c_str());
        Serial.printf("  Used Heap        : %s\n", formatBytes(c.usedHeap).c_str());
        Serial.printf("  Min Free Heap    : %s\n", formatBytes(c.minFreeHeap).c_str());
        Serial.printf("  Heap Usage       : %.1f%%\n", c.heapUsagePercent);
        Serial.println();
        if (c.totalPSRAM > 0)
        {
            float psramUsagePercent = ((float)(c.totalPSRAM - c.freePSRAM) / (float)c.totalPSRAM) * 100.0f;
            Serial.println("MEMORY (PSRAM):");
            Serial.printf("  Total PSRAM      : %s\n", formatBytes(c.totalPSRAM).c_str());
            Serial.printf("  Free PSRAM       : %s\n", formatBytes(c.freePSRAM).c_str());
            Serial.printf("  Used PSRAM       : %s\n", formatBytes(c.totalPSRAM - c.freePSRAM).c_str());
            Serial.printf("  PSRAM Usage      : %.1f%%\n", psramUsagePercent);
            Serial.println();
        }

        Serial.println("TASK & SYSTEM:");
        Serial.printf("  Active Tasks     : %u\n", c.numTasks);
        Serial.printf("  Stack Available  : %u bytes\n", c.stackHighWaterMark);
        Serial.printf("  System Uptime    : %u seconds (%.2f hours)\n",
                      c.uptimeSeconds, c.uptimeSeconds / 3600.0f);
        Serial.println();
        Serial.println("FLASH STORAGE:");
        Serial.printf("  Sketch Size      : %s\n", formatBytes(c.sketchSize).c_str());
        Serial.printf("  Free Flash Space : %s\n", formatBytes(c.freeSketchSpace).c_str());
        Serial.println();
    }

    void printComparison()
    {
        unsigned long duration = millis() - startTime;
        int32_t heapDelta = (int32_t)afterMetrics.freeHeap - (int32_t)beforeMetrics.freeHeap;
        int32_t tasksDelta = (int32_t)afterMetrics.numTasks - (int32_t)beforeMetrics.numTasks;
        int32_t stackDelta = (int32_t)afterMetrics.stackHighWaterMark - (int32_t)beforeMetrics.stackHighWaterMark;
        Serial.println();
        Serial.println("MONITORING REPORT - BEFORE vs AFTER");
        Serial.println();
        Serial.printf("Duration         : %lu ms\n", duration);
        Serial.println();
        Serial.println("HEAP MEMORY:");
        Serial.printf("  Before Free      : %s (%.1f%% used)\n",
                      formatBytes(beforeMetrics.freeHeap).c_str(),
                      beforeMetrics.heapUsagePercent);
        Serial.printf("  After Free       : %s (%.1f%% used)\n",
                      formatBytes(afterMetrics.freeHeap).c_str(),
                      afterMetrics.heapUsagePercent);
        Serial.printf("  Delta            : %s%s %s\n",
                      (heapDelta >= 0) ? "+" : "",
                      formatBytes(abs(heapDelta)).c_str(),
                      (heapDelta > 0) ? "(freed)" : (heapDelta < 0) ? "(allocated)"
                                                                    : "(no change)");
        Serial.println();
        Serial.println("CPU & TASKS:");
        Serial.printf("  CPU Frequency    : %u MHz\n", afterMetrics.cpuFreqMHz);
        Serial.printf("  Number of Cores  : %u\n", afterMetrics.numCores);
        Serial.printf("  Tasks Before     : %u\n", beforeMetrics.numTasks);
        Serial.printf("  Tasks After      : %u\n", afterMetrics.numTasks);
        Serial.printf("  Tasks Delta      : %+d\n", tasksDelta);
        Serial.println();
        Serial.println("STACK USAGE:");
        Serial.printf("  Stack Before     : %u bytes available\n", beforeMetrics.stackHighWaterMark);
        Serial.printf("  Stack After      : %u bytes available\n", afterMetrics.stackHighWaterMark);
        Serial.printf("  Stack Delta      : %+d bytes %s\n", stackDelta, (stackDelta < 0) ? "(deeper)" : (stackDelta > 0) ? "(released)"
                                                                                                                          : "(no change)");
        Serial.println();
    }

    SystemMetrics getCurrentMetrics()
    {
        SystemMetrics current;
        captureMetrics(current);
        return current;
    }

    void printQuickStats()
    {
        SystemMetrics current;
        captureMetrics(current);

        Serial.println();
        Serial.printf("[SYS] CPU:%uMHz | RAM:%s/%s (%.1f%%) | Tasks:%u | Stack:%u | Up:%us\n",
                      current.cpuFreqMHz,
                      formatBytes(current.freeHeap).c_str(),
                      formatBytes(current.totalHeap).c_str(),
                      current.heapUsagePercent,
                      current.numTasks,
                      current.stackHighWaterMark,
                      current.uptimeSeconds);
        Serial.println();
    }

    bool isMemoryLow(uint32_t thresholdBytes = 10240)
    {
        return (ESP.getFreeHeap() < thresholdBytes);
    }

    void checkAndPrintWarnings()
    {
        SystemMetrics c;
        captureMetrics(c);

        bool hasWarnings = false;

        if (c.freeHeap < 10240)
        {
            if (!hasWarnings)
            {
                Serial.println();
                Serial.println("SYSTEM WARNINGS:");
                Serial.println();
                hasWarnings = true;
            }
            Serial.printf("  [WARNING] Low Heap Memory: Only %s free heap remaining!\n",
                          formatBytes(c.freeHeap).c_str());
        }

        if (c.stackHighWaterMark < 512)
        {
            if (!hasWarnings)
            {
                Serial.println();
                Serial.println("SYSTEM WARNINGS:");
                Serial.println();
                hasWarnings = true;
            }
            Serial.printf("  [WARNING] Low Stack Space: Only %u bytes available in current task!\n",
                          c.stackHighWaterMark);
        }

        if (c.heapUsagePercent > 85.0f)
        {
            if (!hasWarnings)
            {
                Serial.println();
                Serial.println("SYSTEM WARNINGS:");
                Serial.println();
                hasWarnings = true;
            }
            Serial.printf("  [WARNING] High Memory Usage: %.1f%% heap used!\n", c.heapUsagePercent);
        }

        if (hasWarnings)
        {
            Serial.println();
        }
    }
};

#endif // SYSTEM_MONITOR_HPP